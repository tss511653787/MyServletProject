/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.gnat;

import org.apache.taglibs.gnat.util.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;
import java.util.*;

public class echoTag extends TagSupport
{
    private String message=null;
    private File f = null;    // real file
    private String file = null; // "file" attribute value
    private boolean append = false;
    private ResourceBundle gnatRB = ListResourceBundle.getBundle("org.apache.taglibs.gnat.util.GnatTagStrings");
    private ResourceBundle gnatERB = ListResourceBundle.getBundle("org.apache.taglibs.gnat.util.GnatExceptionStrings");
        
    public void setMessage(String msg) 
    {
        this.message = msg;
    }

    public void setFile(String file) 
    {
        this.file = file;
    }

    /**
    * Shall we append to an existing file?
    */
    public void setAppend(boolean append) 
    {
        this.append = append;
    }

    
    public int doStartTag() throws JspException
    {
        if (message == null)
        {
            return EVAL_BODY_INCLUDE;
        }
        else
        return SKIP_BODY;
    }
   
    /**
    * "Echoes" message to the JSP's output stream.
    */ 
    public int doEndTag() throws JspException
    {
        if (file != null)
        {
            f = new File(file);
            
            if (f.isDirectory())
            {
                throw new JspTagException( gnatRB.getString("echo.tag") + ": " +
                                           gnatERB.getString("echo.dir.fail") );
            }
            
            FileWriter out = null;
            try 
            {
                out = new FileWriter( f.getAbsolutePath(), append );
                out.write( message, 0, message.length() );
            } 
            catch (IOException ioe) 
            {
                throw new JspTagException( gnatRB.getString("echo.tag") + ": " +
                                           ioe.getMessage() );
            } 
            finally 
            {
                if (out != null) 
                {
                    try 
                    {
                        out.close();
                    } 
                    catch (IOException ioex) 
                    {
                        throw new JspTagException( gnatRB.getString("echo.tag") + ": " + 
                                                   ioex.getMessage() );
                    }
                }
            }
        }
        else if (message != null)
        {
            try
            {
                pageContext.getOut().write(message); 
            }
            catch(IOException ioe)
            {
                throw new JspTagException( gnatRB.getString("echo.tag") + ": " +
                                           ioe.getMessage() ); 
            }
        }
        return EVAL_PAGE;
    }

    /* Put tag attribute accessors down here, out of the way, since they're more for 
       JavaBean completeness than programmer use. 
     */
    public String getMessage() { return message; }

    public String getFile() { return file; }

    public boolean getAppend() { return append; }
}
