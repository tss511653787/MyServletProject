/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.jms;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTag;

/** Creates a JMS TextMessage
  *
  * @author <a href="mailto:jstrachan@apache.org">James Strachan</a>
  * @version $Revision: 216790 $
  */
public class TextMessageTag extends MessageTag implements BodyTag {

    private BodyContent bodyContent;
    private String body;
    
    public TextMessageTag() {
    }

    // BodyTag interface
    //-------------------------------------------------------------------------                                
    public void doInitBody() {
    }

    public int doStartTag() {
        if ( body != null ) {
            return EVAL_BODY_INCLUDE;
        }
        return EVAL_BODY_BUFFERED;
    }
    
    public int doAfterBody() {
        return SKIP_BODY;
    }
    
    public void setBodyContent(BodyContent bodyContent) {
        this.bodyContent = bodyContent;
    }
    
    public void release() {
        super.release();
        body = null;
        bodyContent = null;
    }
    
    // Properties
    //-------------------------------------------------------------------------                                
    public void setBody(String body) throws JMSException {
        this.body = body;
    }
    
    // Implementation methods
    //-------------------------------------------------------------------------                            
    protected Message createMessage() throws JspException, JMSException {
        String text = (body != null) ? body : bodyContent.getString();
        return getConnection().createTextMessage(text);
    }    
}    
