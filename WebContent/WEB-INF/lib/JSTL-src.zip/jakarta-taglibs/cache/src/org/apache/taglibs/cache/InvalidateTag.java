/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 

package org.apache.taglibs.cache;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;

import javax.servlet.jsp.tagext.TagSupport;

import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;

/**
 * <p>Invalidates a particular cache entry, or an entire cache.</p>
 *
 * @author Shawn Bayern
 */

public class InvalidateTag extends TagSupport {

    //*********************************************************************
    // Private state

    String nameExpr;  // tag attribute
    String keyExpr;   // tag attribute

    int scope;        // parsed tag attribute
    String name, key; // parsed tag attribute

    //*********************************************************************
    // Tag logic

    public int doStartTag() throws JspException {
        evaluateExpressions();
        if (this.keyExpr == null || this.key == null) {
            // invalidate whole cache
            CacheUtil.invalidateCache(this.scope, this.name, pageContext);
        } else {
            // invalidate cache item
            CacheUtil.invalidateCachedItem(this.scope, this.name, this.key, pageContext);
        }
        return SKIP_BODY;
    }

    //*********************************************************************
    // Attribute accessors

    public void setScope(String scope) {
        if (scope.equalsIgnoreCase("page")) {
            this.scope = PageContext.PAGE_SCOPE;
        } else if (scope.equalsIgnoreCase("request")) {
            this.scope = PageContext.REQUEST_SCOPE;
        } else if (scope.equalsIgnoreCase("session")) {
            this.scope = PageContext.SESSION_SCOPE;
        } else if (scope.equalsIgnoreCase("application")) {
            this.scope = PageContext.APPLICATION_SCOPE;
        } else {
            throw new IllegalArgumentException("invalid scope");
        }
    }

    public void setName(String nameExpr) {
        this.nameExpr = nameExpr;
    }

    public void setKey(String keyExpr) {
        this.keyExpr = keyExpr;
    }


    //*********************************************************************
    // Constructor and initialization

    public InvalidateTag() {
        super();
        init();
    }

    private void init() {
        this.scope = PageContext.APPLICATION_SCOPE;
        this.name = this.nameExpr = null;
        this.key = this.keyExpr = null;
    }
        
    public void release() {
        init();
        super.release();
    }


    //*********************************************************************
    // Private utility methods

    private void evaluateExpressions() throws JspException {
        if (this.nameExpr != null)
            this.name = (String)ExpressionEvaluatorManager.evaluate("name",
                                                                    this.nameExpr,
                                                                    String.class,
                                                                    this,
                                                                    pageContext);
        if (this.keyExpr != null)
            this.key = (String)ExpressionEvaluatorManager.evaluate("key",
                                                                   this.keyExpr,
                                                                   String.class,
                                                                   this,
                                                                   pageContext);
    }
}
