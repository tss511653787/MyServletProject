/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.gnat;

import javax.servlet.ServletContext;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.lang.reflect.Method;
import java.io.*;
import java.text.*;
import java.util.*;

/**
 * Touch a file - corresponds to the Unix touch command.
 *
 * <p>If the file to touch doesn't exist, an empty one is
 * created. Setting the modification time of files is not supported in
 * JDK 1.1.
 *
 * @author <a href="mailto:stefan.bodewig@megabit.net">Stefan Bodewig</a> 
 * @author <a href="mailto:ssstirling@mediaone.net">Scott Stirling</a> 
 */

public class touchTag extends TagSupport
{
    private File _file;
    private long millis=0;
    private String file="";
    private String datetime = null;
    private ServletContext ctx; // for logging
    private ResourceBundle gnatRB = ListResourceBundle.getBundle("org.apache.taglibs.gnat.util.GnatTagStrings");
    private ResourceBundle gnatERB = ListResourceBundle.getBundle("org.apache.taglibs.gnat.util.GnatExceptionStrings");
        
    private static Method setLastModified = null;
    private static Object lockReflection = new Object();
    
    /**
     * The name of the file to touch.
     */   
    public void setFile(String file) { this.file = file; }

    /**
     * Milliseconds since 01/01/1970 00:00 am.
     */
    public void setMillis(long millis) { this.millis = millis; }

    /**
     * Date in the format MM/DD/YYYY HH:MM AM_PM.
     */
    public void setDatetime(String datetime) { this.datetime = datetime; }
    
    
    public int doStartTag() throws JspException
    {
        ctx = pageContext.getServletContext();
        _file = new File(file);
        
        return SKIP_BODY;
    }
    
    public int doEndTag() throws JspException
    {
        if (datetime != null) 
        {
            DateFormat df = DateFormat.getDateTimeInstance( DateFormat.SHORT,
                                                            DateFormat.SHORT,
                                                            Locale.getDefault() );
            try 
            {
                setMillis( df.parse(datetime).getTime() );
            } 
            catch (ParseException pe) 
            {
                throw new JspTagException( gnatRB.getString("touch.tag") + pe.getMessage() );
            }
            touch();
            return EVAL_PAGE;
        }
        else
        {
            touch();
            return EVAL_PAGE;
        }
    }

    /**
     * Does the actual work.
     */
    private void touch() throws JspTagException
    {
        if ( !_file.exists() ) {
            try 
            {
                FileOutputStream fos = new FileOutputStream(_file);
                fos.write(new byte[0]);
                fos.close();
            } 
            catch (IOException ioe) 
            {
                throw new JspTagException( gnatRB.getString("touch.tag") + ": " +
                                           gnatERB.getString("touch.no.create") + 
                                           ioe.getMessage() );
            }
            ctx.log( gnatRB.getString("touch.success") + file );
        }

        if (setLastModified == null) 
        {
            synchronized (lockReflection) 
            {
                if (setLastModified == null) 
                {
                    try
                    {
                        setLastModified =
                            java.io.File.class.getMethod( "setLastModified",
                                                          new Class[] { Long.TYPE } );
                    }
                    catch(NoSuchMethodException nsme)
                    {
                        throw new JspTagException( gnatRB.getString("touch.tag") +
                                                   gnatERB.getString("touch.nsme") +
                                                   nsme.getMessage() );
                    }
                }
            }
        }

        Long[] times = new Long[1];
        if (millis < 0) 
        {
            times[0] = new Long( System.currentTimeMillis() );
        } 
        else 
        {
            times[0] = new Long(millis);
        }
        try 
        {
            ctx.log( gnatRB.getString("touch.log.mod.time") + file );
            setLastModified.invoke( _file, times );
        } 
        catch (Throwable other) 
        {
            throw new JspTagException( gnatRB.getString("touch.tag") +
                                       gnatERB.getString("touch.throwable") +
                                       file );
        }
    }
   
    public String getFile() { return file; }
    
    public String getDatetime() { return this.datetime; }
    
    public long getMillis() { return this.millis; }
}
