/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.datetime;

import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * JSP Tag <b>amPms</b>, used to loop through all the am/pm strings
 * so that they can be accessed by using the standard
 * JSP &lt;jsp:getProperty&gt; tag.
 * <p>
 * The script variable of name <b>id</b> is availble only within the
 * body of the <b>amPms</b> tag.
 * <p>
 * Loops through all the am/pm strings.
 * <p>
 * If the optional attribute <b>locale</b> is true, the strings
 * are formatted for the clients locale if known.
 * <p>
 * The optional attribute <b>localeRef</b> can be used to specify
 * the name of a page, session, application, or request scope attribute
 * of type java.util.Locale to use.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;amPms&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.datetime.AmPmsTag&lt;/tagclass&gt;
 * &lt;teiclass&gt;org.apache.taglibs.datetime.AmPmsTEI&lt;/teiclass&gt;
 * &lt;bodycontent&gt;JSP&lt;/bodycontent&gt;
 * &lt;info&gt;Loop through all the am/pm names.&lt;/info&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;id&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;locale&lt;/name&gt;
 *     &lt;required&gt;false&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;                             
 *     &lt;name&gt;localeRef&lt;/name&gt;
 *     &lt;required&gt;false&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 * </pre>
 *
 * @author Glenn Nielsen
 */

public class AmPmsTag extends BodyTagSupport
{
    // Static constants
    private static String PATTERN = "yyyy";

    // amPms tag attributes
    private boolean locale_flag = false;
    private String localeRef = null;

    // amPms tag invocation variables
    private String [] amPms = null;
    private int count = 0;

    /**
     * Initializes tag so it can loop through the amPms of the year.
     *
     * @return EVAL_BODY_TAG
     */
    public final int doStartTag() throws JspException
    {
        // Initialize variables
        count = 0;

        SimpleDateFormat sdf;
        // Get a SimpleDateFormat using locale if necessary
        if( localeRef != null ) {
            Locale locale = (Locale)pageContext.findAttribute(localeRef);
            if( locale == null ) {
                throw new JspException(
                    "datetime amPms tag could not find locale for localeRef \"" +
                    localeRef + "\".");
            }

            sdf = new SimpleDateFormat(PATTERN,locale);
        } else if( locale_flag ) {
            sdf = new SimpleDateFormat(PATTERN,
                      (Locale)pageContext.getRequest().getLocale());
        } else {
            sdf = new SimpleDateFormat(PATTERN);
        }

	DateFormatSymbols dfs = sdf.getDateFormatSymbols();
	amPms = dfs.getAmPmStrings();
	// Make sure we skip any blank array elements
        while( count < amPms.length && 
            (amPms[count] == null || amPms[count].length() == 0) )
                count++;
        if( count >= amPms.length )
            return SKIP_BODY;

        pageContext.setAttribute(id,this,PageContext.PAGE_SCOPE);
	return EVAL_BODY_TAG;
    }

    /**
     * Method called at end of each amPms tag.
     *
     * @return EVAL_BODY_TAG if there is another name, or SKIP_BODY if there are no more amPms
     */
    public final int doAfterBody() throws JspException
    {
	// See if we are done looping through amPms
	count++;
        if( count >= amPms.length )
            return SKIP_BODY;
	// Make sure we skip any blank array elements
        while( count < amPms.length && 
	    (amPms[count] == null || amPms[count].length() == 0) )
                count++;

	if( count >= amPms.length )
	    return SKIP_BODY;

	// There is another am/pm, so loop again
	return EVAL_BODY_TAG;
    }

    /**
     * Method called at end of Tag
     * @return EVAL_PAGE
     */
    public final int doEndTag() throws JspException
    {
        pageContext.removeAttribute(id,PageContext.PAGE_SCOPE);
	try
	{
	    if(bodyContent != null)
	    bodyContent.writeOut(bodyContent.getEnclosingWriter());
	} catch(java.io.IOException e)
	{
	    throw new JspException("IO Error: " + e.getMessage());
	}
	return EVAL_PAGE;
    }

    /**
     * Locale flag, if set to true, use am/pm names
     * for client's preferred locale if known.
     *
     * @param boolean eithier <b>true</b> or <b>false</b>
     */
    public final void setLocale(boolean flag)
    {
        locale_flag = flag;
    }

    /**
     * Provides a key to search the page context for in order to get the
     * java.util.Locale to use.
     *
     * @param String name of locale attribute to use
     */
    public void setLocaleRef(String value)
    {
        localeRef = value;
    }

    /**
     * Returns the am/pm name.
     * <p>
     * &lt;jsp:getProperty name=<i>"id"</i> property="name"/&gt;
     *
     * @return String - am/pm name
     */
    public final String getName()
    {  
        return amPms[count];
    }

}
