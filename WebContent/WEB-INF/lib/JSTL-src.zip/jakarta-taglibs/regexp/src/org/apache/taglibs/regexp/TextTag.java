/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.regexp;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * JSP Tag <b>text</b>, used to create a script variable for the
 * text that a regexp will be used on.
 * <p>
 * The body of the tag is used as the text for a regular expression.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;regexp&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.regexp.TextTag&lt;/tagclass&gt;
 * &lt;bodycontent&gt;JSP&lt;/bodycontent&gt;
 * &lt;info&gt;Create a script variable for a text string for use with a regular expression.&lt;/info&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;id&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 * </pre>
 *
 * @see TextData
 *
 * @author Glenn Nielsen
 */

public class TextTag extends BodyTagSupport
{

    /**
     * Returns EVAL_BODY_TAG so the body of the tag can be evaluated.
     *
     * @return EVAL_BODY_TAG
     */
    public final int doStartTag() throws JspException
    {
	return EVAL_BODY_TAG;
    }

    /**
     * Read the body of the regexp tag to obtain a text string for
     * use with a regular expression.
     *
     * @return SKIP_BODY
     */
    public final int doAfterBody() throws JspException
    {
	// Use the body of the tag as regular expression
	BodyContent body = getBodyContent();
	String text = body.getString();
	// Clear the body since we only used it as input as the
	// text string for a regular expression
	body.clearBody();

	// Make sure we have some text for the regexp
        if( text == null )
	    throw new JspException(
		"regexp tag text could not find a text string in body of tag.");

	TextData td = new TextData(text);
	pageContext.setAttribute(id,td,PageContext.PAGE_SCOPE);
	return SKIP_BODY;
    }

}
