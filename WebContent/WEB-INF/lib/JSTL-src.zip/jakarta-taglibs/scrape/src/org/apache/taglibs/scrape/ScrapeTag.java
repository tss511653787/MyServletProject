/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.scrape;

import java.util.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * ScrapeTag - JSP tag <b>scrape</b> is used for setting the begin and end
 *             anchors of a scrape to be preformed by the parent tag of this
 *             tag, PageTag.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;scrape&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.scrape.ScrapeTag&lt;/tagclass&gt;
 * &lt;bodycontent&gt;empty&lt;/bodycontent&gt;
 * &lt;info&gt;
 *     Does the scraping of the page named in the parent page tag
 * &lt;/info&gt;
 *
 * &lt;attribute&gt;
 *	  &lt;name&gt;id&lt;/name&gt;
 *	  &lt;required&gt;true&lt;/required&gt;
 *	  &lt;rtexprval&gt;false&lt;/rtexprval&gt;
 * &lt;/attribute&gt;
 * &lt;attribute&gt;
 *	  &lt;name&gt;begin&lt;/name&gt;
 *	  &lt;required&gt;true&lt;/required&gt;
 *	  &lt;rtexprval&gt;false&lt;/rtexprval&gt;
 * &lt;/attribute&gt;
 * &lt;attribute&gt;
 *	  &lt;name&gt;end&lt;/name&gt;
 *	  &lt;required&gt;true&lt;/required&gt;
 *	  &lt;rtexprval&gt;false&lt;/rtexprval&gt;
 * &lt;/attribute&gt;
 * &lt;attribute&gt;
 *	  &lt;name&gt;strip&lt;/name&gt;
 *	  &lt;required&gt;false&lt;/required&gt;
 *	  &lt;rtexprval&gt;false&lt;/rtexprval&gt;
 * &lt;/attribute&gt;
 * &lt;attribute&gt;
 *	  &lt;name&gt;anchors&lt;/name&gt;
 *	  &lt;required&gt;false&lt;/required&gt;
 *	  &lt;rtexprval&gt;false&lt;/rtexprval&gt;
 * &lt;/attribute&gt;
 * </pre></p></p>
 *
 * @author Rich Catlett
 *
 * @version 1.0
 *
 * @see ScrapeData
 *
 */
public class ScrapeTag extends TagSupport {

    // the beginning anchor for the scrape
    private String begin;
    // the ending anchor for the scrape
    private String end;
    // flag determines if anchors are to be removed from result
    private String anchor = "false";
    // flag determines if tags are to be striped from the result
    private String strip = "false";

    /**
     *  implementation of method from the Tag interface that tells the JSP
     *  what to do upon encountering the end tag for this tag
     *
     *  @throws JSPException  thrown when error occurs in processing the body
     *                        of this method
     *
     *  @return EVAL_PAGE  int telling the tag handler that the rest of the jsp
     *                     page is to be evaluated
     */
  public final int doEndTag() throws JspException {
      // parent tag must be a PageTag, gives access to methods in parent
      PageTag myParent = (PageTag)findAncestorWithClass(this, PageTag.class);

      if(myParent==null) { 
         throw new JspException("ScrapeTag without PageTag");
      } else {
         // place scrapedata object in scrapes HashMap in PageData object
         myParent.setScrape(id, begin, end, anchor, strip);

      }
      return EVAL_PAGE;
  } 

    /**
     *  setter method for the beginning anchor for this scrape    
     *
     *  @param begin  anchor for the beginning of this scrape
     *
     */
  public final void setBegin(String begin) {
      this.begin = begin;
  }

    /**
     *  setter method for the ending anchor for this scrape
     *
     *  @param end  anchor for the end of this scrape
     */
  public final void setEnd(String end) {
      this.end = end;
  }

    /**
     * setter method for anchors
     *
     * @param anchors  value to determine if anchors are included in result
     *
     */
  public final void setAnchors(String anchors) {
      anchor = anchors;
  }

    /**
     * setter method for strip
     *
     * @param strip  value determines if tags are to be removed from result
     *
     */
  public final void setStrip(String strip) {
	this.strip = strip;
    }
}
