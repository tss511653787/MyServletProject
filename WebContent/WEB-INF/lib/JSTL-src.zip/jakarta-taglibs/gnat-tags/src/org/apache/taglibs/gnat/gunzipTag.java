/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.gnat;

import org.apache.taglibs.gnat.util.FileUtil;
import javax.servlet.ServletContext;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;
import java.util.zip.*;
import java.util.*;

public class gunzipTag extends TagSupport
{
    //Need to decide what to do with basedir.  Need to use it for full Ant support,
    //but for JSP taglib, it should be optional.  Perhaps a scripting variable.
    //For now, it's always null until we figure out a good way to use it.
    private String bdir = "";
    private File baseDir;
    private String dest; // the dest attribute
    private File destF;  // the dest file
    private String src;  // the src attribute
    private File source; // the src file
    private ServletContext ctx; // for logging
    private FileUtil fut; // contains some static util methods ripped from Avalon utils

    
    private void setDestF(String dest){ 

        destF = fut.resolveFile(null, dest);
    }

    private void setSource(String src) {

        source = fut.resolveFile(null, src);
    }
    
    public void setDest(String dest) {

        this.dest = dest;
    }

    public void setSrc(String src) {

        this.src = src;
    
    }
    
    public int doStartTag() throws JspException 
    {
        ctx = pageContext.getServletContext();
        
        /* Until we decide how to deal with projects in the Ant tags, bdir is 
         * not set.  So this if statement is always false, for the time being.
         */
        if (!bdir.equals(""))
        {
            baseDir = new File(src);
            //Should fix so that we call different FileUtil methods, depending 
            //whether a basefile name is passed.  Could be an optional attribute.
            setDestF(dest);
            return SKIP_BODY;
        }
        else
        {
            baseDir = new File(bdir);
            setSource(src);
            //Should fix so that we call different FileUtil methods, depending 
            //whether a basefile name is passed.  Could be an optional attribute.
            setDestF(dest);
        
            return SKIP_BODY;
        }
    }
    
    public int doEndTag() throws JspException 
    {
        if (source == null) 
        {
            throw new JspTagException("gunzip: No source file for gunzip specified.");
        }

        if (!source.exists()) 
        {
            throw new JspTagException("gunzip: Source file "+src+" doesn't exist.");
        }

        if (source.isDirectory()) 
        {
            throw new JspException("gunzip: Cannot expand a directory. "+src+" is a directory.");
        }

        if (destF == null) 
        {
            destF = new File(source.getParent());
        }

        if (destF.isDirectory()) 
        {
            String sourceName = source.getName();
            int len = sourceName.length();
            if (len > 3
                && ".gz".equalsIgnoreCase(sourceName.substring(len-3))) 
            {
                destF = new File(destF, sourceName.substring(0, len-3));
            } 
            else 
            {
                destF = new File(destF, sourceName);
            }
        }

        if (source.lastModified() > destF.lastModified()) 
        {
            ctx.log("gunzip: Expanding "+ source.getAbsolutePath() + " to "
                        + destF.getAbsolutePath());

            FileOutputStream out = null;
            GZIPInputStream zIn = null;
            try 
            {
                out = new FileOutputStream(destF);
                zIn = new GZIPInputStream(new FileInputStream(source));
                byte[] buffer = new byte[8 * 1024];
                int count = 0;
                do 
                {
                    out.write(buffer, 0, count);
                    count = zIn.read(buffer, 0, buffer.length);
                } 
                while (count != -1);
            } 
            catch (IOException ioe) 
            {
                String msg = "gunzip: Problem expanding gzip " + ioe.getMessage();
                throw new JspTagException(msg);
            } 
            finally 
            {
                if (out != null) 
                {
                    try 
                    {
                        out.close();
                    } 
                    catch (IOException ioex) 
                    {
                        ioex.printStackTrace();
                    }
                }
                if (zIn != null) 
                {
                    try 
                    {
                        zIn.close();
                    } 
                    catch (IOException ioex) 
                    {
                        ioex.printStackTrace();
                    }
                }
            }
        }
        return EVAL_PAGE;
    }

    public String getDest() {
        return dest;
    }

    public String getSrc() {
        return src;
    }
}
