/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.regexp;

import java.util.*;
import org.apache.oro.text.*;
import org.apache.oro.text.perl.*;
import org.apache.oro.text.regex.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * JSP Tag <b>regexp</b>, used to define a perl regular expression
 * for later use as a script variable.
 * <p>
 * The body of the tag is used as the regular expression.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;regexp&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.regexp.RegexpTag&lt;/tagclass&gt;
 * &lt;bodycontent&gt;JSP&lt;/bodycontent&gt;
 * &lt;info&gt;Create a script variable for a regular expression.&lt;/info&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;id&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 * </pre>
 *
 * @see RegexpData
 *
 * @author Glenn Nielsen
 */

public class RegexpTag extends BodyTagSupport
{
    // The regular expression to use for this tag
    private String regexptext = null;

    /**
     * Returns EVAL_BODY_TAG so the body of the tag can be evaluated.
     *
     * @return EVAL_BODY_TAG
     */
    public final int doStartTag() throws JspException
    {
	return EVAL_BODY_TAG;
    }

    /**
     * Read the body of the regexp tag to obtain the regular expression.
     *
     * @return SKIP_BODY
     */
    public final int doAfterBody() throws JspException
    {
	// Use the body of the tag as regular expression
	BodyContent body = getBodyContent();
	regexptext = body.getString().trim();
	// Clear the body since we only used it as input for the
	// regular expression
	body.clearBody();

	// Make sure we have some text for the regexp
        if( regexptext == null || regexptext.length() <= 0 )
	    throw new JspException(
		"regexp tag regexp could not find a regular expresion in body of tag.");

	// Add the regular expression
	RegexpData rd = new RegexpData(regexptext);
	PatternCacheLRU regexp = RegexpData.getPatternCache();
	try {
            regexp.addPattern(regexptext,
                Perl5Compiler.MULTILINE_MASK|Perl5Compiler.READ_ONLY_MASK);
	} catch(MalformedPatternException e) {
            throw new JspException("regexp tag regexp, malformed pattern \"" +
                regexptext + "\" " + e.getMessage());
        }

	pageContext.setAttribute(id,rd,PageContext.PAGE_SCOPE);
	return SKIP_BODY;
    }
}
