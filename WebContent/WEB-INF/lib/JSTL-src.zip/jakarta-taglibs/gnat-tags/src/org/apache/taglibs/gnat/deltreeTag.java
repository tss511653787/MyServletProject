/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.gnat;

import org.apache.taglibs.gnat.util.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;
import java.util.*;

public class deltreeTag extends TagSupport
{
    private String dir = "";
    private File _f;
    private ResourceBundle gnatRB = ListResourceBundle.getBundle("org.apache.taglibs.gnat.util.GnatTagStrings");
    private ResourceBundle gnatERB = ListResourceBundle.getBundle("org.apache.taglibs.gnat.util.GnatExceptionStrings");
        
    public void setDir(String dir) 
    {
        this.dir = dir;
    }

    /**
    * Deletes a directory and all its files and subdirectories.
    */ 
    public int doEndTag() throws JspException
    {
        if (!dir.equals(""))
        {
            _f = FileUtil.resolveFile(null,dir);
            
            try
            {
                FileUtil.forceDelete(_f);
            }
            catch(IOException ioe)
            {
                throw new JspTagException(gnatRB.getString("deltree.tag") +": "+ ioe.getMessage());
            }
        }
        else
        {
            throw new JspTagException(gnatRB.getString("deltree.tag") +": "+ gnatERB.getString("empty.dir.attribute"));
        }
        return EVAL_PAGE;
    }

    /* Put tag attribute accessors down here, out of the way, since they're more for 
       JavaBean completeness than programmer use. 
     */
    public String getDir() 
    {
        return dir;
    }
}
