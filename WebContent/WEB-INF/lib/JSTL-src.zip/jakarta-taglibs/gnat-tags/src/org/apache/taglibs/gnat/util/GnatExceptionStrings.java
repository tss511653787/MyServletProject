/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.gnat.util;

import java.io.*;
import java.util.*;

/**
 * This class provides a ResourceBundle for Gnat Tag Library Exception strings.
 *
 * @author <a href="mailto:sstirling@mediaone.net">Scott M. Stirling</a>
 */
public class GnatExceptionStrings extends ListResourceBundle
{
      public Object[][] getContents() {
                   return contents;
           }
           static final Object[][] contents = {
           // LOCALIZE THIS
                   { "empty.dir.attribute",  "Non-empty \"dir\" attribute value required." },
                   { "duplicate.mkdir.fail", "Unable to create dir as a directory with that name already exists: " },
                   { "unknown.mkdir.fail",   "Directory creation failed for an unknown reason: " },
                   { "echo.dir.fail", "Can't echo to a directory; make sure value of \"file\" is a regular file." },
                   { "touch.nsme", "You must use a 1.2 or higher JVM with this tag: " },
                   { "touch.no.create", "Could not create file " },
                   { "touch.throwable", "Exception setting the modification time of " },
           // END OF MATERIAL TO LOCALIZE
           };
}
