/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 

package org.apache.taglibs.cache;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;

import javax.servlet.jsp.tagext.BodyTagSupport;

import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;

/**
 * <p>Caches a fragment of a JSP page.</p>
 *
 * @author Shawn Bayern
 */

public class CacheTag extends BodyTagSupport {

    //*********************************************************************
    // Private state

    private String nameExpr;  // tag attribute
    private String keyExpr;   // tag attribute

    private int scope;        // parsed tag attribute
    private String name, key; // parsed tag attribute

    private LRUCache cache;   // cache
    private String cached;    // value from cache

    //*********************************************************************
    // Tag logic

    public int doStartTag() throws JspException {
        evaluateExpressions();
        this.cache = CacheUtil.getCache(this.scope, this.name, pageContext);
        this.cached = this.cache.get(this.key);
        if (this.cached != null) {
            return SKIP_BODY;
        } else {
            return EVAL_BODY_BUFFERED;
        }
    }

    public int doEndTag() throws JspException {
        try {
            String s = this.cached;
            if (s == null) {
                if (bodyContent == null || bodyContent.getString() == null) {
                    s = "";
                } else {
                    s = bodyContent.getString().trim();
                }
                this.cache.put(this.key, s);
            }
            pageContext.getOut().write(s);
        } catch (IOException ex) {
            throw new JspException(ex);
        }
        return EVAL_PAGE;
    }

    //*********************************************************************
    // Attribute accessors

    public void setScope(String scope) {
        if (scope.equalsIgnoreCase("page")) {
            this.scope = PageContext.PAGE_SCOPE;
        } else if (scope.equalsIgnoreCase("request")) {
            this.scope = PageContext.REQUEST_SCOPE;
        } else if (scope.equalsIgnoreCase("session")) {
            this.scope = PageContext.SESSION_SCOPE;
        } else if (scope.equalsIgnoreCase("application")) {
            this.scope = PageContext.APPLICATION_SCOPE;
        } else {
            throw new IllegalArgumentException("invalid scope");
        }
    }

    public void setName(String nameExpr) {
        this.nameExpr = nameExpr;
    }

    public void setKey(String keyExpr) {
        this.keyExpr = keyExpr;
    }


    //*********************************************************************
    // Constructor and initialization

    public CacheTag() {
        super();
        init();
    }

    private void init() {
        this.scope = PageContext.APPLICATION_SCOPE;
        this.name = this.nameExpr = "";
        this.key = this.keyExpr = "";
    }
    
    public void release() {
        init();
        super.release();
    }


    //*********************************************************************
    // Private utility methods

    private void evaluateExpressions() throws JspException {
        this.name = (String)ExpressionEvaluatorManager.evaluate("name",
                                                                this.nameExpr,
                                                                String.class,
                                                                this,
                                                                pageContext);
        this.key = (String)ExpressionEvaluatorManager.evaluate("key",
                                                               this.keyExpr,
                                                               String.class,
                                                               this,
                                                               pageContext);
    }
}
