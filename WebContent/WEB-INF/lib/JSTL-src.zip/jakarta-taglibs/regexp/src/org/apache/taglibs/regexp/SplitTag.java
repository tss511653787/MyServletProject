/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.regexp;

import java.util.ArrayList;
import java.util.Iterator;
import org.apache.oro.text.*;
import org.apache.oro.text.perl.*;
import org.apache.oro.text.regex.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * JSP Tag <b>split</b>, used to implement a perl style
 * split on the text.
 * <p>
 * The body of the tag iterates through each string generated
 * from the split. The normal &lt;jsp:getProperty/&gt; can be
 * used to get the value of each string split out using the
 * id of the <b>split</b> tag script variable.
 * <p>
 * The attribute <b>text</b> must be set to the id of a
 * <b>text</b> tag.
 * <p>
 * By default, the split is done on whitespace.  Set the
 * optional attribute <b>regexp</b> to the id of a <b>regexp</b>
 * tag script variable id to perform the split using a custom
 * regular expression.
 * <p>
 * You can set the optional tag attribute <b>limit</b> to the
 * number of items you want to limit the split to.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;split&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.regexp.SplitTag&lt;/tagclass&gt;
 * &lt;bodycontent&gt;JSP&lt;/bodycontent&gt;
 * &lt;info&gt;Implements a perl style split on the text.&lt;/info&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;id&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;text&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;regexp&lt;/name&gt;
 *     &lt;required&gt;false&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;limit&lt;/name&gt;
 *     &lt;required&gt;false&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 * </pre>
 *
 * @see RegexpTag
 * @see TextTag
 * @see RegexpData
 * @see TextData
 *
 * @author Glenn Nielsen
 */

public class SplitTag extends BodyTagSupport
{
    private String regexpid = null;
    private String textid = null;
    private int limit = -1;
    private Iterator values = null;
    private String value = null;

    /**
     * Setup to split the text based on supplied attributes
     *
     * @return EVAL_BODY_TAG if there is a string from the split, BODY_SKIP if no strings resulted from the split
     */
    public final int doStartTag() throws JspException
    {
	TextData td = (TextData)pageContext.getAttribute(textid,PageContext.PAGE_SCOPE);
	if( td == null )
	    throw new JspException(
		"regexp tag split could not find text tag with id: " +
		textid);

	Perl5Util perl = new Perl5Util(RegexpData.getPatternCache());
	String spliton = "/\\s+/m";
	if( regexpid != null ) {
            RegexpData rd = (RegexpData)pageContext.getAttribute(regexpid,PageContext.PAGE_SCOPE);
            if( rd == null )
                throw new JspException(
                    "regexp tag split could not find regexp tag with id: " +
                    regexpid);
	    spliton = rd.getRegexp();
	}
	ArrayList split = new ArrayList();
	if( limit > -1 ) {
	    perl.split(split,spliton,td.getText(),limit);
	} else {
	    perl.split(split,spliton,td.getText());
	}
        values = split.iterator();
	if( !values.hasNext() ) {
	    return SKIP_BODY;
	}

	value = (String)values.next();
	pageContext.setAttribute(id,this,PageContext.PAGE_SCOPE);

	return EVAL_BODY_TAG;
    }

    /** 
     * Method called at end of each iteration of the split tag
     *
     * @return EVAL_BODY_TAG if there is another string split, or BODY_SKIP if there are no more strings
     */
    public final int doAfterBody() throws JspException
    {
	if( !values.hasNext() ) {
	    return SKIP_BODY;
	}
	value = (String)values.next();
	return EVAL_BODY_TAG;
    }

    /**
     * Method called at end of split Tag
     *
     * @return EVAL_PAGE
     */
    public final int doEndTag() throws JspException
    {
        if( id != null && id.length() > 0 )
            pageContext.removeAttribute(id,PageContext.PAGE_SCOPE);
	try {
	    if(bodyContent != null)
		bodyContent.writeOut(bodyContent.getEnclosingWriter());
	} catch(java.io.IOException e) {
	    throw new JspException("IO Error: " + e.getMessage());
	}
	return EVAL_PAGE;
    }

    /*
     * Set the optional attribute <b>regexp</b>
     *
     * @param String name of regexp script variable
     */
    public final void setRegexp(String str)
    {   
	regexpid = str;
    }

    /*
     * Set the required attribute <b>text</b>
     *
     * @param String name of text script variable
     */
    public final void setText(String str)
    {               
        textid = str;
    }

    /*
     * Set the optional attribute <b>limit</b> to the
     * number of strings to split out of text.
     *
     * @param int number of strings to limit split to
     */
    public final void setLimit(int limit)
    {
	this.limit = limit;
    }

    /**
     * String split out from text can be obtained by the JSP page
     * using &lt;jsp:getProperty name=<i>"id"</i> property="split"/&gt;
     *
     * @return String - string that was split out from text
     */
    public final String getSplit()
    {
	return value;
    }

}
