/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.random;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.util.Random;

import javax.servlet.jsp.JspException;

/**
 * The RandomNum will produce a variable set of random numbers.
 *
 * @author Rich Catlett
 *
 * @version 1.0
 *
 */

public class RandomNum {

    /**
     * the random number is stroed here for retrieval
     */
    private Long randomnum = null;
    /**
     * the random number is stroed here for retrieval
     */
    private Float randomfloat = null;
    /**
     * flag tells if a float value is expected or not
     */
    private boolean floatvalue = false;
    /**
     * upper bound in which to search for a number defaults to 9
     */
    private long upper = 100;
    /**
     * lower bound in which to search for a number defaults to 0
     */
    private long lower = 0;
    /**
     * the algorithm to use for a SecureRandom object
     */
    private String algorithm = null;
    /**
     * the provider package to check for the algorithm
     */
    private String provider = null;
    /**
     * boolean value that marks if a Random or SecureRandom object is to be used,
     * default value of false says that a Random object will be used
     */
    private boolean secure = false;
    /**
     * random object that could be used
     */
    private Random random = null;
    /**
     * SecureRandom object that could be used
     */
    private SecureRandom secrandom = null;

    /**
     * nethod determines if a Random or SecureRandom object is to be used to
     * generate the random number
     *
     */
    private final float getFloat() {
	if (random == null)
	    return secrandom.nextFloat();
	else
	    return random.nextFloat();
    }

    /**
     * generate the Random object that will be used for this random number 
     * generator
     *
     */
    public final void generateRandomObject() throws JspException {

	// check to see if the object is a SecureRandom object
	if (secure) {
	    try {
		// get an instance of a SecureRandom object
		if (provider != null)
		    // search for algorithm in package provider
		    secrandom = SecureRandom.getInstance(algorithm, provider);
		else
		    secrandom = SecureRandom.getInstance(algorithm);
	    } catch (NoSuchAlgorithmException ne) {
		throw new JspException(ne.getMessage());
	    } catch (NoSuchProviderException pe) {
		throw new JspException(pe.getMessage());
	    }
        } else
	    random = new Random();
    }

    /**
     * generate the random number
     *
     */
    private final void generaterandom() {

	int tmprandom = 0;  // temp storage for random generated number
	Integer rand;

	// check to see if float value is expected
	if (floatvalue)
	    randomfloat = new Float(getFloat());
        else
	    randomnum = new Long(lower + (long) ((getFloat() * (upper - lower))));
    }

    /**
     * get the random number, for use with the 
     * &lt;jsp:getProperty name=<i>"id"</i> property="floatval"/&gt;
     *
     * @return - randomly created float value
     *
     * @throws - JspException if the range entered for the number generator is not
     *           0-1
     */
    public final Number getRandom() {

	generaterandom(); // generate the first random number

	if (floatvalue)
	    return randomfloat;
	else
	    return randomnum;
    }

    /**
     * set the Range
     *
     * @param low  lower bound of the range
     * @param up  upper bound of the range
     *
     */
    public final void setRange(long low, long up) {

	// set the upper and lower bound of the range
	lower = low;
	upper = up;

	// check to see if a float value is expected
	if ((lower == 0) && (upper == 1))
	    floatvalue = true;
    }

    /**
     * set the algorithm name
     *
     * @param value  name of the algorithm to use for a SecureRandom object
     *
     */
    public final void setAlgorithm(String value) {
	algorithm = value;
	secure = true;  // a SecureRandom object is to be used
    }

    /**
     * set the provider name
     *
     * @param value  name of the package to check for the algorithm
     *
     */
    public final void setProvider(String value) {
	provider = value;
    }
}
