/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.jms;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.servlet.jsp.JspException;

import org.apache.commons.messenger.Messenger;

/** Creates a JMS message
  *
  * @author <a href="mailto:jstrachan@apache.org">James Strachan</a>
  * @version $Revision: 216790 $
  */
public class MessageTag extends AbstractTag {

    /** The name of the Message variable that is created */
    private String var;    
    
    /** The JMS Message created */
    private Message message;
    
    /** The Messenger used to access the JMS connection */
    private Messenger connection;
    
    public MessageTag() {
    }
    
    /** Adds a JMS property to the message */
    public void addProperty(String name, Object value) throws JspException, JMSException {
        Message message = getMessage();
        message.setObjectProperty(name, value);
    }
    
    // BodyTag interface
    //-------------------------------------------------------------------------                    
    public int doStartTag() throws JspException {
        return EVAL_BODY_INCLUDE;
    }
    
    public int doEndTag() throws JspException {
        try {
            if ( var == null ) {
                // expose message to parent message consumer
                SendTag tag = (SendTag) findAncestorWithClass( this, SendTag.class );
                if ( tag == null ) {
                    throw new JspException("<jms:message> tags must either have the 'var' attribute specified or be used inside a <jms:send> tag");
                }
                tag.setMessage( getMessage() );            
            }
            else {
                pageContext.setAttribute( var, getMessage() );
            }
        }
        catch (JMSException e) {
            throw new JspException( "Failed to create message: " + e, e );
        }
        return EVAL_PAGE;
    }
    
    public void release() {
        super.release();
        var = null;
        connection = null;
        message = null;
    }
    
    
    // Properties
    //-------------------------------------------------------------------------                            
    
    /** Sets the name of the variable that the message will be exported to */
    public void setVar(String var) {
        this.var = var;        
    }
    
    public Messenger getConnection() throws JspException, JMSException {
        if ( connection == null ) {
            return findConnection();
        }
        return connection;
    }
    
    public void setConnection(Messenger connection) {
        this.connection = connection;
    }
    
    public Message getMessage() throws JspException, JMSException {
        if ( message == null ) {
            message = createMessage();
        }
        return message;
    }
    

    // JMS related properties
    
    public void setCorrelationID(String correlationID) throws JspException, JMSException {
        getMessage().setJMSCorrelationID(correlationID);
    }
    
    public void setReplyTo(Destination destination) throws JspException, JMSException {
        getMessage().setJMSReplyTo(destination);
    }
    
    public void setType(String type) throws JspException, JMSException {
        getMessage().setJMSType(type);
    }
    
    // Implementation methods
    //-------------------------------------------------------------------------                            
    protected Messenger findConnection() throws JspException, JMSException {
        ConnectionContext messengerTag = (ConnectionContext) findAncestorWithClass( this, ConnectionContext.class );
        if ( messengerTag == null ) {
            throw new JspException("This tag must be within a <jms:connection> tag or the 'connection' attribute should be specified");
        }
        return messengerTag.getConnection();
    }
    
    protected Message createMessage() throws JspException, JMSException {
        return getConnection().createMessage();
    }    
}    
