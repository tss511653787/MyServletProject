/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.random;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

/**
 * The RandomNumTag will set up a random number generator which can be accessed by
 * the <b>jsp:getProperty</b> tag.
 *
 * &lt;tag&gt;
 *	&lt;name&gt;randomnum&lt;/name&gt;
 *	&lt;tagclass&gt;org.apache.taglibs.random.RandomNumTag&lt;/tagclass&gt;
 *	&lt;bodycontent&gt;empty&lt;/bodycontent&gt;
 *	&lt;info&gt;Creates a variable length random number generator&lt;/info&gt;
 *
 *	&lt;attribute&gt;
 *		&lt;name&gt;id&lt;/name&gt;
 *		&lt;required&gt;true&lt;/required&gt;
 *		&lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *	&lt;/attribute&gt;
 *	&lt;attribute&gt;
 *		&lt;name&gt;range&lt;/name&gt;
 *		&lt;required&gt;false&lt;/required&gt;
 *		&lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *	&lt;/attribute&gt;
 *	&lt;attribute&gt;
 *		&lt;name&gt;algorithm&lt;/name&gt;
 *		&lt;required&gt;false&lt;/required&gt;
 *		&lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *	&lt;/attribute&gt;
 *	&lt;attribute&gt;
 *		&lt;name&gt;provider&lt;/name&gt;
 *		&lt;required&gt;false&lt;/required&gt;
 *		&lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *	&lt;/attribute&gt;
 * &lt;/tag&gt;
 *
 * @author Rich Catlett
 *
 * @version 1.0
 *
 */

public class RandomNumTag extends TagSupport {

    /**
     * upper bound in which to search for a number defaults to 9
     */
    private long upper = 100;
    /**
     * lower bound in which to search for a number defaults to 0
     */
    private long lower = 0;
    /**
     * the algorithm to use for a SecureRandom object
     */
    private String algorithm = null;
    /**
     * the provider package to check for the algorithm
     */
    private String provider = null;

    /**
     * implementation of method from the Tag interface that tells the JSP what
     * to do upon encountering the start tag for this tag set
     *
     * @return SKIP_BODY - integer value telling the JSP engine to not evaluate
     *                     the body of this tag
     *
     * @throws JspException  thrown when error occurs in processing the body of
     *                       this method
     *
     */
    public final int doStartTag() throws JspException {

	RandomNum random = new RandomNum();

	// set the range in the randomnum class
	random.setRange(lower, upper);

	// check to see if algorithm and provider have been set and set them in the
	// randomnum 
	if (algorithm != null)
	    random.setAlgorithm(algorithm);
	if (provider != null)
	    random.setProvider(provider);

	// generate the random object to be used either a Random or SecureRandom
	random.generateRandomObject();

	// place random into page scope so that it will be available as a 
	// script variable
	pageContext.setAttribute(id, random, PageContext.PAGE_SCOPE);

	return SKIP_BODY;
    }

    /**
     * set the Range
     *
     * @param value  String value that determines range from which the random
     *               number will be chosen
     *
     * @throws JspException if the lowerbound is greater than the upperbound
     *
     */
    public final void setRange(String value) throws JspException {
	try {
	  upper = new Integer(value.substring(value.indexOf('-') + 1)).longValue();
	} catch (NumberFormatException nfe) {
	    pageContext.getServletContext().log("upper attribute could not be" +
			       " turned into an Integer default value was used");
	}
	try {
	  lower = new Integer(value.substring(0, value.indexOf('-'))).longValue();
	} catch (NumberFormatException nfe) {
	    pageContext.getServletContext().log("lower attribute could not be" +
			       " turned into an Integer default value was used");
	}

	// check that the range is possible i.e. the upperbound is not lower than
	// the lowerbound
	if (upper < lower)
	    throw new JspException("You can't have a range where the lowerbound" +
				   " is higher than the upperbound.");
    }

    /**
     * set the algorithm name
     *
     * @param value  name of the algorithm to use for a SecureRandom object
     *
     */
    public final void setAlgorithm(String value) {
	algorithm = value;
    }

    /**
     * set the provider name
     *
     * @param value  name of the package to check for the algorithm
     *
     */
    public final void setProvider(String value) {
	provider = value;
    }
}
