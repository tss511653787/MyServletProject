/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 


package org.apache.taglibs.jndi;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import javax.naming.*;
import java.io.*;

/**
 *
 * @author  Danno Ferrin <shemnon@earthlink.net>
 * @version $Revision: 216819 $
 */
public class LookupTag extends TagSupport {

    private Context context;
    private String contextRef;
    private String name  = "";
    private int scope = PageContext.PAGE_SCOPE;
    private String type = "java.lang.Object";
    private Name nameObject;
    
    
    /** Creates new LookupTag */
    public LookupTag() {
    }

    /** Getter for property context.
     * @return Value of property context.
     */
    public Context getContext() {
        return context;
    }

    /**
     * Setter for property context.
     * @param context New value of property context.
     */
    public void setContext(Context context) {
        this.context = context;
    }

    /**
     * Setter for property contextRef.
     * @param contextRef New value of property contextRef.
     */
    public void setContextRef(String contextRef) {
        this.contextRef = contextRef;
    }

    /** 
     * Setter for property scope.
     * @param scope New value of property scope.
     */
    public void setScope(String scope) {
        this.scope = decodeScope(scope);
    }

    /** 
     * Getter for property type.
     * @return Value of property type.
     */
    public String getType() {
        return type;
    }

    /** 
     * Setter for property type
     * @param type New value of property type.
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Getter for property name.
     * @return Value of property name.
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for property name.
     * @param name New value of property name.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for property nameObject.
     * @return Value of property nameObject.
     */
    public Name getNameObject() {
        return nameObject;
    }

    /**
     * Setter for property nameObject.
     * @param nameObject New value of property nameObject.
     */
    public void setNameObject(Name nameObject) {
        this.nameObject = nameObject;
    }

    public int doStartTag() throws JspException {
        return SKIP_BODY;
    }
    
    public int doEndTag() throws JspException {
        if( contextRef != null ) {
            context = null;
            Object o = pageContext.findAttribute(contextRef);
            if (o instanceof Context) {
                context = (Context)o;
            }
        }
        if (context == null) {
            throw new JspException("context not set in a lookup invocation");
        }
        Object o;
        try {
            if (nameObject != null) {
                o = context.lookup(nameObject);
            } else {
                o = context.lookup(name);
            }
            if (Class.forName(type).isInstance(o)) {
                pageContext.setAttribute(getId(), o, scope);
            }
        } catch (NamingException ne) {
            throw new JspException(ne.toString());
        } catch (ClassNotFoundException cnfe) {
            // no need to handle classNotFound,since the enclosing page
            // compiles the variable with the same class and it wouldn't
            // compile since it wasn't found.
        }
                
        return EVAL_PAGE;
    }
    
    static int decodeScope(String scope) {
        if (scope.equalsIgnoreCase("request")) {
            return PageContext.REQUEST_SCOPE;
        } else if (scope.equalsIgnoreCase("session")) {
            return PageContext.SESSION_SCOPE;
        } else if (scope.equalsIgnoreCase("application")) {
            return PageContext.APPLICATION_SCOPE;
        } else {
            return PageContext.PAGE_SCOPE;
        }
    }        
}
