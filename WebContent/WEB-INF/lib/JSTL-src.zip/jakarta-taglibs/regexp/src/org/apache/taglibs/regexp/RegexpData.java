/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.regexp;

import java.util.*;
import org.apache.oro.text.*;
import org.apache.oro.text.perl.*;
import org.apache.oro.text.regex.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * Script variable data for JSP Tag <b>regexp</b>, used to define a perl
 * regular expression for later use.
 * <p>
 * Uses a static PatternCacheLRU to cache up to 100 regular expressions.
 *
 * @see RegexpTag
 *
 * @author Glenn Nielsen
 */

public class RegexpData
{

    // Static compiled regexp patterns
    // So that each time a regexp tag is used we don't have to recompile the regexp
    // if the regular expression is being reused.
    // Set to a capacity of 100 unique patterns, this should be enough
    // for most users.
    private static PatternCacheLRU regexp = new PatternCacheLRU(100);

    // The regular expression to use
    private String regexptext = null;

    RegexpData(String text)
    {
	regexptext = text;
    }

    /*
     * Get the plain text regular expression
     *
     * @return String - regular expression text
     */
    public final String getRegexp()
    {
	return regexptext;
    }

    /*
     * Get the static PatternCacheLRU
     *
     * @return PatternCacheLRU - the static PatternCacheLRU
     */
    public final static PatternCacheLRU getPatternCache()
    {
	return regexp;
    }
}
