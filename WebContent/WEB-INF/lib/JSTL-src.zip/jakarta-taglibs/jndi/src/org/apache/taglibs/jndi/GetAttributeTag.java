/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 

package org.apache.taglibs.jndi;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import javax.naming.*;
import javax.naming.directory.*;

import java.io.*;

/**
 *
 * @author  Danno Ferrin <shemnon@earthlink.net>
 * @version $Revision: 216819 $
 */
public class GetAttributeTag extends BodyTagSupport {

    private String attributeRef;
    private Object attributeObject;
    private int scope = PageContext.PAGE_SCOPE;
    private String attribute;
    private int multivalueMode = ONE_VALUE;;
    private NamingEnumeration nameEnum;
    private Attribute theAttribute;
    
    /** Only take one value (first value if ordered) */
    public static final int ONE_VALUE = 1;
    /** Body provides a separator for the values */
    public static final int SEPARATE_VALUES = 2;
    /** body should be iterated for each value */
    public static final int ITERATE_VALUES = 3;

    /** Creates new GetAttributeTag */
    public GetAttributeTag() {
    }

    /**
     * Setter for property scope.
     * @param Scope New value of property scope.
     */
    public void setScope(String scope) {
        this.scope = decodeScope(scope);
    }

    /**
     * Getter for property object.
     * @return Value of property object.
     */
    public Object getObject() {
        return attributeObject;
    }

    /**
     * Setter for property object.
     * @param object New value of property object.
     */
    public void setObject(DirContext object) {
        attributeObject = object;
    }

    /**
     * Setter for property ref.
     * @param ref New value of property ref.
     */
    public void setRef(String ref) {
        attributeRef = ref;
    }

    /**
     * Getter for property attribute.
     * @return Value of property attribute.
     */
    public String getAttribute() {
        return attribute;
    }

    /**
     * Setter for property attribute.
     * @param attribute New value of property attribute.
     */
    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    /**
     * Getter for property multivalue
     * @return Value of property multivalue.
     */
    public String getMultivalue() {
        return decodeMultivalue(multivalueMode);
    }

    /**
     * Setter for property multivalue.
     * @param multivalue New value of property multivalue.
     */
    public void setMultivalue(String multivalue) {
        multivalueMode = decodeMultivalue(multivalue);
    }

    public int doStartTag() throws JspException {
        // Initialize invocation variables
        nameEnum = null;
        theAttribute = null;

        if( attributeRef != null ) {
            attributeObject = pageContext.findAttribute(attributeRef);
        }

        try {
            if ((attributeObject instanceof DirContext) 
             && (attributeObject != null)) {
                attributeObject = ((DirContext)attributeObject).getAttributes("", 
                        new String[] {attribute});
            }

            if ((attributeObject instanceof SearchResult) 
             && (attributeObject != null)) {
                attributeObject = ((SearchResult)attributeObject)
                        .getAttributes(); 
            }

            if ((attributeObject instanceof Attributes)
             && (attributeObject != null)) {
                attributeObject = ((Attributes)attributeObject).get(attribute);
            }

            if (attributeObject instanceof Attribute) {
                // don't need to worry about nulls, 
                // it will behave properly since nulls can be cast
                // to anything
                theAttribute = (Attribute)attributeObject;
            } 
        } catch (NamingException ne) {
        }
        
        if (theAttribute == null) {
            if (getId() != null) {
                pageContext.removeAttribute(getId(), scope);
            }
            return SKIP_BODY;
        } else {
            if (multivalueMode == ONE_VALUE) {
                try {
                    pageContext.getOut().print(theAttribute.get());
                    if (getId() != null) {
                        pageContext.setAttribute(getId(), 
                                theAttribute.get(), scope);
                    }
                } catch (NamingException ne) {
                    // if it throws this, we just fail to export it
                    // hence we do nothing
                } catch (IOException ioe) {
                    // however ioexceprtion is worse!
                    throw new JspException(ioe.toString());
                }
                return SKIP_BODY;
            } else {
                try {
                    nameEnum = theAttribute.getAll();
                    if (nameEnum.hasMoreElements()) {
                        if (multivalueMode == SEPARATE_VALUES) {
                            // recycle attributeObject field
                            attributeObject = nameEnum.nextElement();
                            if (nameEnum.hasMoreElements()) {
                                return EVAL_BODY_TAG;
                            } else {
                                try {
                                    pageContext.getOut().print(attributeObject);
                                } catch (IOException ioe) {
                                    throw new JspException(ioe.toString());
                                }
                                return SKIP_BODY;
                            }
                        } else {
                            pageContext.setAttribute(getId(), 
                                    nameEnum.nextElement(), scope);
                            return EVAL_BODY_TAG;
                        }
                    } else {
                        return SKIP_BODY;
                    }
                } catch (NamingException ne) {
                    // if there is no forAll, skip the body
                    return SKIP_BODY;
                }
            }
        }
    }

    public void doInitBody() throws JspException {
        try {
            if (multivalueMode == SEPARATE_VALUES) {
                bodyContent.print(attributeObject);
            }
        } catch (IOException ioe) {
            throw new JspException(ioe.toString());
        }
    }
        

    public int doAfterBody() throws JspException {
        if (multivalueMode == SEPARATE_VALUES) {
            try {
                bodyContent.print(nameEnum.nextElement());
            } catch (IOException ioe) {
                throw new JspException(ioe.toString());
            }
            if (nameEnum.hasMoreElements()) {
                return EVAL_BODY_TAG;
            } else {
                return SKIP_BODY;
            }
        } else {
            if (nameEnum.hasMoreElements()) {
                pageContext.setAttribute(getId(), 
                        nameEnum.nextElement(), scope);
                return EVAL_BODY_TAG;
            } else {
                return SKIP_BODY;
            }
        }
            
    }
    
    public int doEndTag() throws JspException {
        try {
            if (bodyContent != null) {
                bodyContent.writeOut(pageContext.getOut());
            } 
        } catch (IOException ioe) {
            throw new JspException(ioe.toString());
        }
        if (nameEnum != null) {
            try {
                nameEnum.close();
            } catch (NamingException ne) {
                // we are trying to free the resource.
                // if it throws fits, hope it gets GCed
                nameEnum = null;
            }
        }
        return EVAL_PAGE;
    }
    
    public static String decodeMultivalue(int multivalue) {
        switch (multivalue) {
            case ONE_VALUE:
                return "one";
            case SEPARATE_VALUES:
                return "separator";
            case ITERATE_VALUES:
                return "iterate";
            default:
                return null;
        }
    }
    
    public static int decodeMultivalue(String multivalue) {
        if (multivalue.equalsIgnoreCase("one")) {
            return ONE_VALUE;
        } else if (multivalue.equalsIgnoreCase("separator")) {
            return SEPARATE_VALUES;
        } else if (multivalue.equalsIgnoreCase("iterate")) {
            return ITERATE_VALUES;
        } else {
            return  -1;
        }
    }

    public static int decodeScope(String scope) {
        if (scope.equalsIgnoreCase("request")) {
            return PageContext.REQUEST_SCOPE;
        } else if (scope.equalsIgnoreCase("session")) {
            return PageContext.SESSION_SCOPE;
        } else if (scope.equalsIgnoreCase("application")) {
            return PageContext.APPLICATION_SCOPE;
        } else {
            return PageContext.PAGE_SCOPE;
        }
    }
}
