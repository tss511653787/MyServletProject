/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.gnat;

import org.apache.taglibs.gnat.util.FileUtil;
import javax.servlet.ServletContext;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;
import java.util.zip.*;
import java.util.*;

public class gzipTag extends TagSupport
{
    //Need to decide what to do with basedir.  Need to use it for full Ant support,
    //but for JSP taglib, it should be optional.  Perhaps a scripting variable.
    //For now, it's always null until we figure out a good way to use it.
    private String bdir = "";
    private File baseDir;
    private String zipfile;
    private File zf;
    private String src;
    private File source;
    private ServletContext ctx; 
    private FileUtil fut;

    
    private void setZF(String zipfile){ 

        zf = fut.resolveFile(null, zipfile);
    }

    private void setSource(String src) {

        source = fut.resolveFile(null, src);
    }
    
    public void setZipfile(String zipfile) {

        this.zipfile = zipfile;
    }

    public void setSrc(String src) {

        this.src = src;
    
    }
    
    public int doStartTag() throws JspException {
        ctx = pageContext.getServletContext();
        if (!bdir.equals(""))
        {
            baseDir = new File(src);
            //See notes in gunzipTag.java
            setZF(zipfile);
            return SKIP_BODY;
        }
        else
        {
            baseDir = new File(bdir);
            setSource(src);
            //See notes in gunzipTag.java
            setZF(zipfile);
            return SKIP_BODY;
        }
    }
    
    public int doEndTag() throws JspException {
        if (zf == null) 
        {
            throw new JspTagException("gzip: zipfile attribute is required");
        }

        if (source == null) 
        {
            throw new JspTagException("gzip: src attribute is required");
        }
        ctx.log("gzip: Building gzip: " + zf.getAbsolutePath());

        GZIPOutputStream zOut = null;
        try 
        {
            zOut = new GZIPOutputStream(new FileOutputStream(zf));

            if (source.isDirectory()) 
            {
                ctx.log ("gzip: Cannot Gzip a directory!");
            } 
            else 
            {
                zipFile(source, zOut);
            }
        } 
        catch (IOException ioe) 
        {
            String msg = "gzip: Problem gzipping file: " + ioe.getMessage();
            throw new JspTagException(msg);
        } 
        finally 
        {
            if (zOut != null) 
            {
                try 
                {
                    zOut.close();
                }
                catch (IOException e) 
                {
                    e.printStackTrace();
                }
            }
        }
        return EVAL_PAGE;
    }

    private void zipFile(InputStream in, GZIPOutputStream zOut)
        throws IOException
    {
        byte[] buffer = new byte[8 * 1024];
        int count = 0;
        do 
        {
            zOut.write(buffer, 0, count);
            count = in.read(buffer, 0, buffer.length);
        } 
        while (count != -1);
    }

    private void zipFile(File file, GZIPOutputStream zOut)
        throws IOException
    {
        FileInputStream fIn = new FileInputStream(file);
        try 
        {
            zipFile(fIn, zOut);
        } 
        finally 
        {
            fIn.close();
        }
    }

    public String getZipfile() {
        return zipfile;
    }

    public String getSrc() {
        return src;
    }
}
