/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.io;

import javax.servlet.ServletContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyContent;

/** Defines a HTTP header for the current HTTP request tag
  *
  * @author <a href="mailto:james.strachan@metastuff.com">James Strachan</a>
  * @version $Revision: 216774 $
  */
public class URLHeaderTag extends AbstractBodyTag {

    /** Stores the name of the request */
    private String name;
    
    /** Stores the value of the request */
    private String value;
    
    
    // BodyTag interface
    //-------------------------------------------------------------------------                    
    public int doStartTag() throws JspException {
        if ( value != null ) {
            fireHeader();
            return SKIP_BODY;
        }
        return EVAL_BODY_TAG;
    }
    
    public int doAfterBody() throws JspException {
        BodyContent body = getBodyContent();
        value = body.getString();
        body.clearBody();
        fireHeader();
        return EVAL_PAGE;
    }
    
    public void release() {
        name = null;
        value = null;
    }
    
    // Properties
    //-------------------------------------------------------------------------                    
    /** Sets the name of the HTTP header 
      */
    public void setName(String name) {
        this.name = name;
    }
    
    /** Sets the value of the HTTP header. 
      * If no value is set then the body of the tag is used
      */
    public void setValue(String value) {
        this.value = value;
    }
    
    // Implementation methods
    //-------------------------------------------------------------------------                        
    protected void fireHeader() throws JspException {
        URLTag tag = (URLTag) findAncestorWithClass( this, URLTag.class );
        if ( tag == null ) {
            throw new JspException("<io:header> tag must be within a <io:url> tag");
        }
        tag.addHeader( name, value );
    }
    
}
