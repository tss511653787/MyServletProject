/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 

package org.apache.taglibs.jndi;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

import java.util.Hashtable;
import java.util.Enumeration;

import javax.naming.*;
import javax.naming.directory.*;

/**
 *
 * @author  Danno Ferrin <shemnon@earthlink.net>
 * @version $Revision: 216819 $
 */
public class UseDirContextTag extends UseContextTag {
 
    public Class getClassOfExportedObject() {
        return DirContext.class;
    }

    protected Object getObjectToExport() throws JspException
    {
        try {
            Context ctx = new InitialDirContext(env);
            if (url != null) {
                Object o = ctx.lookup(url);
                if (o instanceof DirContext) {
                    ctx = (DirContext) o;
                }
            }
            return ctx;
        } catch (NamingException ne) {
            //XXX add some sort of logging hook?
            throw new JspException(ne.toString());
        }
    }    
    
    //TODO when implicit context scoping w/o ID is implemented also have this listen to 
    //     getAttribute tags and forEachAttribute itteration tags

}
