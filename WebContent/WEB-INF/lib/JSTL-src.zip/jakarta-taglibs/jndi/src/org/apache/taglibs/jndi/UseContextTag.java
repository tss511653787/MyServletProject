/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 

package org.apache.taglibs.jndi;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

import java.io.*;
import java.util.Hashtable;
import java.util.Enumeration;

import javax.naming.*;
/**
 *
 * @author  Danno Ferrin <shemnon@earthlink.net>
 * @version $Revision: 216819 $
 */
public class UseContextTag extends BodyTagSupport {
 
    Hashtable env = new Hashtable();
    //id handled by bodytagsupport
    private int scope = PageContext.PAGE_SCOPE;
    String url;
    
    /** 
     * Creates new UseDirContextTag 
     */
    public UseContextTag() {
        
    }
    
    /** 
     * Setter for property envRef.
     * <BR>Bad refs will be silently ignored.
     * @param envRef New value of property envRef.
     */
    public void setEnvRef(String envRef) {
        Object o = pageContext.findAttribute(envRef);
        if ((o != null) && (o instanceof Hashtable)) {
            setEnv((Hashtable)o);
        }
    }
    
    /** 
     * Getter for property env.
     * @return Value of property env.
     */
    public Hashtable getEnv() {
        return env;
    }

    /** 
     * Setter for property env.
     * This copies the Hashtable in and does not mutate the hashtable passed in.
     * @param env New value of property env.
     */
    public void setEnv(Hashtable env) {
        Enumeration e = env.keys();
        while (e.hasMoreElements()) {
            String s = (String)e.nextElement();
            //XXX only put stuff not there?  This could be an intersting
            //XXX example of ordered attributes in a custom tag then
            this.env.put(s, env.get(s));
        }
    }
    
    /** 
     * Getter for property providerUrl.
     * @return Value of property providerUrl.
     */
    public String getProviderUrl() {
        try {
            return (String) env.get(Context.PROVIDER_URL);
        } catch (ClassCastException cce) {
            return null;
        }
    }
    
    /**
     * Setter for property providerUrl.
     * @param providerUrl New value of property providerUrl.
     */
    public void setProviderUrl(String providerUrl) {
        env.put(Context.PROVIDER_URL, providerUrl);
    }

    /**
     * Getter for property url
     * @return Value of property url.
     */
    public String getUrl() {
        return url;
    }

    /**
     * Setter for property url.
     * @param url New value of property url.
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * Getter for property intialFactory.
     * @return Value of property intialFactory.
     */
    public String getInitialFactory() {
        try {
            return (String) env.get(Context.INITIAL_CONTEXT_FACTORY);
        } catch (ClassCastException cce) {
            return null;
        }
    }

    /**
     * Setter for property intialFactory.
     * @param intialFactory New value of property intialFactory.
     */
    public void setInitialFactory(String initialFactory) {
        env.put(Context.INITIAL_CONTEXT_FACTORY, initialFactory);
    }

    /**
     * Getter for property authoritative.
     * @return Value of property authoritative.
     */
    public String getAuthoritative() {
        try {
            return (String) env.get(Context.AUTHORITATIVE);
        } catch (ClassCastException cce) {
            return null;
        }
    }

    /**
     * Setter for property authoritative.
     * @param authoritative New value of property authoritative.
     */
    public void setAuthoritative(String authoritative) {
        env.put(Context.AUTHORITATIVE, authoritative);
    }

    /**
     * Getter for property batchsize.
     * @return Value of property batchsize, or -1 if not set
     */
    public int getBatchsize() {
        Object o = env.get(Context.BATCHSIZE);
        if (o instanceof Integer) {
            return ((Integer)o).intValue();
        } else if (o != null) {
            return Integer.parseInt(o.toString());
        } else {
            return -1;
        }
    }

    /**
     * Setter for property batchsize.
     * @param batchsize New value of property batchsize.
     */
    public void setBatchsize(int batchsize) {
        env.put(Context.BATCHSIZE, new Integer(batchsize));
    }

    /** 
     * Getter for property objectFactories.
     * @return Value of property objectFactories.
     */
    public String getObjectFactories() {
        try {
            return (String) env.get(Context.OBJECT_FACTORIES);
        } catch (ClassCastException cce) {
            return null;
        }
    }

    /**
     * Setter for property objectFactories.
     * @param objectFactories New value of property objectFactories.
     */
    public void setObjectFactories(String objectFactories) {
        env.put(Context.OBJECT_FACTORIES, objectFactories);
    }

    /**
     * Getter for property stateFactories.
     * @return Value of property stateFactories.
     */
    public String getStateFactories() {
        try {
            return (String) env.get(Context.STATE_FACTORIES);
        } catch (ClassCastException cce) {
            return null;
        }
    }

    /**
     * Setter for property stateFactories.
     * @param stateFactories New value of property stateFactories.
     */
    public void setStateFactories(String stateFactories) {
        env.put(Context.STATE_FACTORIES, stateFactories);
    }

    /**
     * Getter for property urlPkgPrefixes.
     * @return Value of property urlPkgPrefixes.
     */
    public String getUrlPkgPrefixes() {
        try {
            return (String) env.get(Context.URL_PKG_PREFIXES);
        } catch (ClassCastException cce) {
            return null;
        }
    }

    /**
     * Setter for property urlPkgPrefixes.
     * @param urlPkgPrefixes New value of property urlPkgPrefixes.
     */
    public void setUrlPkgPrefixes(String urlPkgPrefixes) {
        env.put(Context.URL_PKG_PREFIXES, urlPkgPrefixes);
    }
    
    /**
     * Getter for property dnsUrl.
     * @return Value of property dnsUrl.
     */
    public String getDnsUrl() {
        try {
            return (String) env.get(Context.DNS_URL);
        } catch (ClassCastException cce) {
            return null;
        }
    }

    /**
     * Setter for property dnsUrl
     * @param dnsUrl New value of property dnsUrl
     */
    public void setDnsUrl(String dnsUrl) {
        env.put(Context.DNS_URL, dnsUrl);
    }
    
    public void supplementFromAttributes(String entry) {
        if (!env.containsKey(entry)) {
            Object o = pageContext.findAttribute(entry);
            if (o != null) {
                env.put(entry, o);
            }
        }
    }
    
    /**
     * Setter for property scope.
     * @param scope New value of property scope.
     */
    public void setScope(String scope) {
        if (scope.equalsIgnoreCase("request")) {
            this.scope = PageContext.REQUEST_SCOPE;
        } else if (scope.equalsIgnoreCase("session")) {
            this.scope = PageContext.SESSION_SCOPE;
        } else if (scope.equalsIgnoreCase("application")) {
            this.scope = PageContext.APPLICATION_SCOPE;
        }
    }
    
    protected void pullInSupplimentalAttributes() {
        supplementFromAttributes(Context.INITIAL_CONTEXT_FACTORY);
        supplementFromAttributes(Context.OBJECT_FACTORIES);
        supplementFromAttributes(Context.STATE_FACTORIES);
        supplementFromAttributes(Context.URL_PKG_PREFIXES);
        supplementFromAttributes(Context.PROVIDER_URL);
        supplementFromAttributes(Context.DNS_URL);
    }
    
    protected Object getObjectToExport() throws JspException
    {
        try {
            Context ctx = new InitialContext(env);
            if (url != null) {
                Object o = ctx.lookup(url);
                if (o instanceof Context) {
                    ctx = (Context) o;
                }
            }
            return ctx;
        } catch (NamingException ne) {
            throw new JspException("JNDI useContext tag could not find url: "+ne.getMessage());
        }
    }    

    public Class getClassOfExportedObject() {
        return Context.class;
    }

    public int doEndTag() throws JspException {
        Object o = pageContext.getAttribute(getId(), scope);
        if (o != null) {
            if (!getClassOfExportedObject().isInstance(o)) {
                o = null;
            }
        }
        if (o == null) {
            pullInSupplimentalAttributes();
            o = getObjectToExport();
            pageContext.setAttribute(getId(), o, scope);
        }
        return EVAL_PAGE;
    }
}
