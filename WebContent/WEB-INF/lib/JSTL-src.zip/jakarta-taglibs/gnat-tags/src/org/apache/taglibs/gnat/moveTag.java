/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.gnat;

import org.apache.taglibs.gnat.util.*;
import javax.servlet.ServletContext;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;
import java.util.*;

public class moveTag extends BodyTagSupport
{
    //private File _f;
    private String file = "";
    private String todir = "";
    private String tofile = "";
    private boolean filtering = false;
    private boolean flatten = false;
    private boolean overwrite = true;
    private boolean includeEmptyDirs = true;
    private ResourceBundle gnatRB = ListResourceBundle.getBundle("org.apache.taglibs.gnat.util.GnatTagStrings");
    private ResourceBundle gnatERB = ListResourceBundle.getBundle("org.apache.taglibs.gnat.util.GnatExceptionStrings");
    
    public void setFile(String file) {
        this.file = file;
    }
    
    public void setFiltering(boolean filtering) {
        this.filtering = filtering;
    }
    
    public void setFlatten(boolean flatten) {
        this.flatten = flatten;
    }
    
    public void setTodir(String todir) {
        this.todir = todir;
    }
    
    public void setTofile(String tofile) {
        this.tofile = tofile;
    }
    
    public void setOverwrite(boolean overwrite) {
        this.overwrite = overwrite;
    }
    
    public void setIncludeEmptyDirs(boolean includeEmptyDirs) {
        this.includeEmptyDirs = includeEmptyDirs;
    }
    
    
    public int doStartTag() throws JspException
    {
        return SKIP_BODY;
    }
    
    public int doEndTag() throws JspException
    {
        return EVAL_PAGE;
    }
    
    public String getFile()       { return file;      }
    public boolean getFiltering() { return filtering; }
    public boolean getFlatten()   { return flatten;   }
    public String getTodir()      { return todir;     }
    public String getTofile()     { return tofile;    }
    public boolean getIncludeEmptyDirs() { return includeEmptyDirs; }
    public boolean getOverwrite() { return overwrite; }
}
