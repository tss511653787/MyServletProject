/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.io;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.Reader;
import java.io.Writer;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

/** A collection of bean and introspection helper methods.
  * 
  * @author <a href="mailto:james.strachan@metastuff.com">James Strachan</a>
  * @version $Revision: 216774 $
  */
public class BeanHelper {

    protected static final Object[] NULL_ARGUMENTS = {};
    
    /** Gets the value of the given property
      * 
      * @param bean is the JavaBean which contains the property
      * @param propertyName is the name of the property to set
      *
      * @return the value of the given property
      */
    public static Object getProperty( Object bean, String propertyName ) throws JspException {
        try {
            PropertyDescriptor descriptor
                = getPropertyDescriptor( bean, propertyName );
            Method method = descriptor.getReadMethod();
            return method.invoke( bean, NULL_ARGUMENTS );
        }
        catch (Exception e) {
            throw new JspException( 
                "Failed to get property: " + propertyName 
                + " on bean: " +  bean + ". Exception: " + e );
        }
    }
    
    /** Sets the value of the given property
      * 
      * @param bean is the JavaBean which contains the property
      * @param propertyName is the name of the property to set
      * @param value is the value of the property to set
      *
      * @return true if the property was set else false if it could not be set
      */
    public static void setProperty( Object bean, String propertyName, Object value ) throws JspException {
        try {
            PropertyDescriptor descriptor
                = getPropertyDescriptor( bean, propertyName );
            Method method = descriptor.getWriteMethod();
            Object[] arguments = { value };
            method.invoke( bean, arguments );
        }
        catch (Exception e) {
            throw new JspException( 
                "Failed to set property: " + propertyName 
                + " on bean: " +  bean + ". Exception: " + e );
        }
    }
    
    /** @return a PropertyDescriptor for the given bean and property name
      */
    protected static PropertyDescriptor getPropertyDescriptor( 
        Object bean, 
        String propertyName 
    ) throws JspException {
        try {
            Class beanClass = bean.getClass();
            BeanInfo beanInfo = Introspector.getBeanInfo( beanClass );

            // Its a shame the JDK doesn't have a helper method on BeanInfo for this
            PropertyDescriptor[] descriptors = beanInfo.getPropertyDescriptors();
            if ( descriptors != null ) {
                int size = descriptors.length;
                for ( int i = 0; i < size; i++ ) {
                    PropertyDescriptor descriptor = descriptors[i];
                    String name = descriptor.getName();
                    if ( propertyName.equals( name ) ) {
                        return descriptor;
                    }
                }
            }
            throw new JspException( 
                "No such property: " + propertyName + " on bean: " +  bean 
            );
        }
        catch (IntrospectionException e) {
            throw new JspException( 
                "Failed to instrospect bean: " +  bean + ". Exception: " + e 
            );
        }
    }
}
