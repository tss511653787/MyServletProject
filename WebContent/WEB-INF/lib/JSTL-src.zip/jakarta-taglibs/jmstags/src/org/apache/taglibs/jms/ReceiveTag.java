/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.jms;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.servlet.jsp.JspException;

/** Receives a JMS message.
  *
  * @author <a href="mailto:jstrachan@apache.org">James Strachan</a>
  * @version $Revision: 216790 $
  */
public class ReceiveTag extends MessageOperationTag {

    private static final long DEFAULT_TIMEOUT = -1L;
    
    private long timeout = DEFAULT_TIMEOUT;
    private String var;
    
    public ReceiveTag() {
    }
    
    // Tag interface
    //-------------------------------------------------------------------------                    
    public int doStartTag() throws JspException {
        return EVAL_BODY_INCLUDE;
    }
    
    public int doEndTag() throws JspException {
        try {
            Destination destination = getDestination();
            if ( destination == null ) {
                throw new JspException( "No destination specified. Either specify a 'destination' attribute or use a nested <jms:destination> tag" );
            }
            Message message = null;
            if ( timeout > 0 ) {
                message = getConnection().receive( destination, timeout );
            }
            else if ( timeout == 0 ) {
                message = getConnection().receiveNoWait( destination );
            }
            else {
                message = getConnection().receive( destination );
            }
            onMessage( message );
        }
        catch (JMSException e) {
            throw new JspException( "Failed to receive JMS message: " + e, e );
        }
        return EVAL_PAGE;
    }
    
    public void release() {
        super.release();
        timeout = DEFAULT_TIMEOUT;
        var = null;
    }
    
    
    // Properties
    //-------------------------------------------------------------------------                                
    public String getVar() {
        return var;
    }
    
    public void setVar(String var) {
        this.var = var;
    }    
    
    public long getTimeout() {
        return timeout;
    }
    
    public void setTimeout(long timeout) {
        this.timeout = timeout;
    }
    
    // Implementation methods
    //-------------------------------------------------------------------------                            
    
    /** Processes the incoming message */
    protected void onMessage( Message message ) {
        if ( message != null ) {
            pageContext.setAttribute( var, message );
        }
        else {
            pageContext.removeAttribute( var );
        }
    }
}    
