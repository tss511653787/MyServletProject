/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.scrape;

import java.net.*;
import java.io.*;
import java.util.*;
import java.security.KeyStore;
import javax.servlet.jsp.PageContext;
//import javax.net.ssl.SSLSocket;
//import com.sun.net.ssl.SSLContext;
//import com.sun.net.ssl.KeyManagerFactory;
//import javax.net.ssl.SSLSocketFactory;
//import javax.net.ssl.HandshakeCompletedEvent;
//import javax.net.ssl.HandshakeCompletedListener;

/**
 * HttpConnection - the class that creates the http connection that the rest of the
 *                  package uses 
 *
 * @author Rich Catlett
 *
 * @version 1.0
 *
 */
public class HttpConnection {

    /**
     * the URL of this connection
     */
    private URL url = null;
    /**
     * socket to make the connection on
     */
    private Socket socket = null;
    /**
     * hashmap to hold http response headers
     */
    private HashMap keys = null;
    /**
     * set holds the set of keys for the hashmap keys
     */
    private Vector headers = new Vector(12, 5);
    /**
     * value to determine if headers have been retrieved or not
     */
    private boolean gotten = false;
    /**
     * separator in the response headers list
     */
    private static final char keySeparator = ':';
    /**
     * flag tells if this object is making it's http connection through proxies
     */
    private boolean useproxy = false;
    /**
     * the port to use for the proxy connection
     */
    private int pport = 3128;
    /**
     * the proxy server to use for the connection
     */
    private String pserver = null;
    /**
     * error from proxy server when connection failed
     */
    private String proxyerror = null;
    /**
     * boolean value determines if the connection to to travel via a secure
     * connection
     */
    //private boolean ssl = false;
    /**
     * base64 encoded username and password used for proxy authentication
     */
    private String auth = null;
    /**
     * outputstream for this connection
     */
    private OutputStream out = null;
    /**
     * the port for this connection will default to 80 for http and 443 for https
     */
    private int port;
    /**
     * internet address for this connection
     */
    private InetAddress dst = null;
    /**
     * the password to the client keystore for ssl authentication
     */
    private String sslpass = null;
    /**
     * response code from the request
     */
    private int responseCode = 0;
    /**
     * response message from the request
     */
    private String responseMessage = null;
    /**
     * the request method HEAD or GET
     */
    private String requestMethod = "GET";
    /**
     * flag determines if the the class is connected
     */
    private boolean connected = false;
    /**
     * pageContext of the servlet used for logging
     */
    private PageContext pageContext = null;
    /**
     * pagedata object that represents the page to be scraped
     */
    private PageData pagedata = null;

    /**
     * constructor creates an instance of HttpConnection and calls the super class
     * HttpURLConnection
     *
     * @param url - url of the http server to connect to
     *
     */
    public HttpConnection(URL url, PageData pd, PageContext pc) {
    //public HttpConnection(URL url, boolean secure, String pass, PageContext pc) {
	this.url = url;
	//ssl = secure;
	//sslpass = pass;
	pageContext = pc;
        pagedata = pd;
        if (pagedata.getProxyServer() != null) {
            useproxy = true;
	}
    }

    /**
     * constructor creates an instance of HttpConnection and calls the super
     * class HttpURLConnection, this instance of the class connects through a 
     * proxy server that requires authentication
     *
     * @param url  url of the http server to connect to
     * @param port  the port to use for the connection to the proxy server
     * @param server  the proxy server
     * @param secure  is the link going over https
     * @param name  user name for authentication
     * @param pass  password for authentication
     *
     */
    public HttpConnection(URL url, int port, String server, String authstring, 
    PageContext pc) {
	//public HttpConnection(URL url, int port, String server, boolean secure, 
	//String pass, String authstring, PageContext pc) {
        this.url = url;
        pport = port;
        pserver = server;
        useproxy = true;
	//ssl = secure;
	//sslpass = pass;
	pageContext = pc;
	if (authstring != null)
	    auth = "Basic " + 
		new sun.misc.BASE64Encoder().encode(authstring.getBytes());
    }

    /**
     * Implementation of the abstract method defined in the URLConnection class
     * establish a connection to an HTTP server and send request
     *
     * @throws IOException - if connection cannot be made
     *
     */
    public void connect() throws IOException {

	if (connected) // connected is defined in URLConnection
	    return;

	// get port number
	if ((port = getURL().getPort()) == -1) {
	    if (pagedata.getSSL())
		port = 443;  // default port for https
            else
	        port = 80;   // default port for http
	}

	// create the socket for this connection
	//if (!pagedata.getSSL()) {
	    // make a connection for http
	    if (useproxy) {
		// create socket to the proxy server
		InetAddress proxy = InetAddress.getByName(pagedata.getProxyServer());
		// make the connection to the proxy server
		socket = new Socket(proxy, pagedata.getProxyPort());
	    } else {
		// create the Internet address object for this url
		InetAddress dst = InetAddress.getByName(getURL().getHost());
		// create a regular socket
		socket = new Socket(dst, port);
	    }
	    // get the outputstream
	    out = socket.getOutputStream();
	    //} else
	    // make a connection for https
	    //makeSecureConnection();

	// set timeout value for this connection
	try {
	    socket.setSoTimeout(20000);
	} catch (SocketException se) {
	    pageContext.getServletContext().
		log("timeout could not be set on the socket");
	}
	connected = true;  // set value of connected
    }

    /**
     * Implementation of the abstract method defined in the HttpURLConnection
     * class cut the current connection this object has
     *
     */
    public void disconnect() {
	try {
	    socket.close();  // close the connection
	    socket = null;
	} catch (IOException ie) {}

	// reset values on the connection
	out = null;
	gotten = false;
	keys = null;

	connected = false;  // set value of connected
    }

    /**
     * Implementation of the abstract method defined in the HttpURLConnection
     * class this implementation does not use proxy
     *
     * @return  false proxy servers not used by this implementation
     *
     */
    public boolean usingProxy() {
	return useproxy;
    }

    /**
     * Override the default method provided in the URLConnection class
     *
     */
    public InputStream getInputStream() throws IOException {
	if (!connected)
	    connect();

	return socket.getInputStream();
    }

    /**
     * Override the default method provided in the URLConnection class
     *
     */
    public OutputStream getOutputStream() throws IOException {
	if (!connected)
	    connect();

	return socket.getOutputStream();
    }

    /**
     * get the request method
     *
     * @return - the request method
     *
     */
    public String getRequestMethod() {
	return requestMethod;
    }

    /**
     * set the request method
     *
     * @param String  GET or HEAD
     *
     */
    public void setRequestMethod(String value) {
	requestMethod = value;
    }

    /**
     * Override the default method provided in the HttpURLConnection class
     * Get the response code for this connection
     *
     * @return - the response code of the connection, -1 if no valid response
     *
     */
    public int getResponseCode() {
	return responseCode;
    }

    /**
     * Override the default method provided in the HttpURLConnection class
     * Get the response message for the last request
     *
     * @return - the response message of the last request
     *
     */
    public String getResponseMessage() {
	return responseMessage;
    }

    /**
     * send the request to the server
     *
     * @throws IOException
     *
     */
    public void sendRequest() throws IOException {
        ArrayList headers = pagedata.getHeaders();
	//System.out.println("sendRequest() useproxy = " + useproxy + "\n" + 
	//		getRequestMethod() + " " + url.toString() + " HTTP/1.1\r\n");
	// send request to the server via http check for not ssl because if a proxy
	// and ssl are in use the request is to be tunneled through the proxy
	// connection and is already setup
	if (useproxy && !pagedata.getSSL()) {
	    send(out, getRequestMethod() + " " + url.toString() + " HTTP/1.1\r\n");
	    if (pagedata.getAuth() != null)
		send(out, "Proxy-Authorization: " + pagedata.getAuth() + "\r\n");
            if (headers != null) {
                ArrayList name = (ArrayList) headers.get(0);
                ArrayList value = (ArrayList) headers.get(1);
                for (int i = 0; i < name.size(); i++) {
                    send(out, name.get(i) + ": " + value.get(i) + "\r\n");
		}
	    }
	    send(out, "Connection: close\r\n");
        } else {
	    send(out, getRequestMethod() + " " + url.getFile() + " HTTP/1.1\r\n");
	    send(out, "Host: " + url.getHost() + "\r\n");
            if (headers != null) {
                ArrayList name = (ArrayList) headers.get(0);
                ArrayList value = (ArrayList) headers.get(1);
                for (int i = 0; i < name.size(); i++) {
                    send(out, name.get(i) + ": " + value.get(i) + "\r\n");
		}
	    }
	}
	//send(sslout, "Accept: text/plain, text/html \r\n");
	send(out, "\r\n");

	// get the response message to the request
	responseMessage = recv(socket.getInputStream());
	try {
	    responseCode = Integer.parseInt(responseMessage.substring(9, 12));
	} catch (NumberFormatException nfe) {responseCode = -1;}

	// check for and take care of redirection
	if (responseCode == 301 || responseCode == 302)
	    doRedirection();
    }

    /**
     * take care of redirection if the response code is 301 or 302
     *
     */
    private void doRedirection() throws IOException {
	setURL(getHeaderField("Location"));
	// log the redirection
	pageContext.getServletContext().
           log(getResponseMessage() + ": Connection redirected to " +
               getHeaderField("Location"));
	// close connection so that a new one can be opened to Location:
	disconnect();
	connect();
	sendRequest();
    }


    /**
     * make a regular http connection
     *
     * @throws IOException
     *
     */
    boolean makeTunnelConnection() throws IOException {
	//System.out.println("makeTunnelConnection() sending CONNECT to proxy CONNECT "
	//		   + url.getHost() + ":" + port + " HTTP/1.1");
  
	// create socket to the proxy server
	InetAddress proxy = InetAddress.getByName(pagedata.getProxyServer());
	// make the connection to the proxy server
	socket = new Socket(proxy, pagedata.getProxyPort());

	// get the outputstream
	out = socket.getOutputStream();

	send(out, "CONNECT " + url.getHost() + ":" + port + " HTTP/1.0\r\n");
	if (pagedata.getAuth() != null) {
	  //System.out.println("sending the auth line Proxy-Authorization: " + auth);
	    send(out, "Proxy-Authorization: " + pagedata.getAuth() + "\r\n");
	}
	send(out, "\r\n");

	// get the response from the proxy server for the connection
	String sb = recv(socket.getInputStream());

	if (sb.startsWith("HTTP/1.0 200"))
	    // connection successful
	    return true;
        else {
	    // connection failed
	    proxyerror = sb.substring(9);
	    return false;
	}
    }

    /**
     * get the sslsocket
     *
     * @return - the created sslsocket
     *
     * @throws IOException
     *
     *
    private void makeSecureConnection() throws IOException {
	System.out.println("makeSecureConnection()");
	if (useproxy) {
	    // going to tunnel the ssl connection through the proxy
	    if (!makeTunnelConnection()) {
		// throw exception for some reason
	        throw new IOException("Connection to the proxy server could not be "
				      + "extablished: " + proxyerror);
	    }
	}
	SSLSocket sslsocket = null;
	try {
	    SSLSocketFactory sslfactory;
	    SSLContext context = SSLContext.getInstance("TLS");
	    // if client authorization is required for the ssl connection init the
	    // SSLContext with the clients keystore
	    if (sslpass != null) {
		System.out.println("using client authentication for ssl");
		KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
	        FileInputStream filein = 
		 new FileInputStream(System.getProperty("javax.net.ssl.trustStore"));
		KeyStore ks = KeyStore.getInstance("JKS");
		ks.load((InputStream)filein, null);
		System.out.println("password = " + sslpass);
		char[] password = pagedata.getSslPass.toCharArray();
		kmf.init(ks, password);
		context.init(kmf.getKeyManagers(), null, null);
                sslfactory = context.getSocketFactory();
	    } else
		// use the default SSLSocketFactory
		sslfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();

	    if (!useproxy)
		sslsocket = (SSLSocket) sslfactory.createSocket(dst, port);
            else {
                sslsocket = 
                   (SSLSocket) sslfactory.createSocket(socket, url.getHost(), 
						       port, true);
		//System.out.println("created the tunneled socket");
	    }
	} catch (java.security.GeneralSecurityException nsae) {
	    // should never happen
	    throw new IOException("HttpConnection.connect(): " + 
				"creating tunneled sslsocket " + nsae.toString());
	}
	System.out.println("starting sslhandshake");
	sslsocket.startHandshake();
	socket = sslsocket;
	out = sslsocket.getOutputStream();
	System.out.println("makeSecureConnection() DONE");
    }
    */
    /**
     * Override default provided in URLConnection
     *
     * @param n - index of the desired header field
     *
     */
    public String getHeaderField(int n) {
        getHeaders();  // get headers from http response

        if (n < headers.size()) {  // make sure n is not out of bounds
            return getField((String)headers.elementAt(n));  // return header field
        }
        return null;
    }

    /**
     * Override default provided in URLConnection
     *
     * @return - LastModified header or 0 if LastModified does not exist
     *
     */
    public long getLastModified() {
        getHeaders();  // get headers from http response

        String header = (String)keys.get("LastModified");
        if (header != null) {
            try {
        	return new Integer(header).longValue();
            } catch (NumberFormatException nfe) {
        	return 0;
            }
        }
	return 0;
    }

    /**
     * Override default provided in URLConnection
     *
     * @return - the Expiration header or 0 if Expiration does not exist
     *
     */
    public long getExpiration() {
        getHeaders();  // get headers from http response

	String header = (String)keys.get("Expiration");
        if (header != null) {
            try {
        	return new Integer(header).longValue();
            } catch (NumberFormatException nfe) {
        	return 0;
            }
        }
	return 0;
    }

    /**
     * Override default provided in URLConnection
     *
     * @param key - name of the desired header field
     *
     */
    public String getHeaderField(String key) {
        getHeaders();  // get headers from http response

        return (String)keys.get(key.toLowerCase());  // return desired header field
    }

    /**
     * Override default provided in URLConnection
     *
     * @param n   value returned if header is null
     * @param key  header to retreive
     *
     * @return - header as an integer
     */
    public int getHeaderFieldInt(String key, int n) {
        getHeaders();  // get headers from http response

	String header = (String)keys.get(key.toLowerCase());
        if (header != null) {
	    try {
		n = new Integer(header).intValue();
	    } catch (NumberFormatException nfe) {
		// do nothing the default value specified will be returned
	    }
	}
	return n;
    }

    /**
     * Override default provided in URLConnection
     *
     * @param n - index of the desired header field
     *
     */
    public String getHeaderFieldKey(int n) {
        getHeaders();  // get headers from http response

        if (n < headers.size()) {  // make sure n is not out of bounds
	    // return name of nth header field
            return getKey((String)headers.elementAt(n));
        }
        return null;
    }

    /**
     * Set the URL for this connection
     *
     * @throws MalformedURLException
     *
     */
    protected void setURL(String value) throws MalformedURLException {
	url = new URL(value);
    }

    /**
     * get the URL of this connection
     *
     * @return - the URL for this connection
     */
    public URL getURL() {
	return url;
    }

    /**
     * Helper routine for parsing header field
     *
     * @param str - complete header field name and value separated by :
     *
     * @return - name of header field
     *
     */
    private String getKey(String str) {
        if (str == null)
            return null;
        int ind = str.indexOf(keySeparator);
        if (ind >= 0)
            return str.substring(0, ind).toLowerCase();
        return null;
    }

    /**
     * Helper routine for parsing header field
     *
     * @param str - complete header field name and value separated by :
     *
     * @return value of header field
     *
     */
    private String getField(String str) {
        if (str == null)
            return null;
        int ind = str.indexOf(keySeparator);
        if (ind >= 0)
            return str.substring(ind+1).trim();
        else
            return str;
    }

    /**
     * Helper routine that reads header from HTTP connection
     *
     */
    private void getHeaders() {

	String header;  // holds one full header name value pair

	// check if headers have been gotten previously
        if (gotten)
            return;
        gotten = true;  // set gotten

	// initialize keys
	keys = new HashMap();

        try {
            connect();  // make connection

	    // get inputstream from connection
            InputStream in = getInputStream();

	    header = recv(in);  // get initial header field

            while (true) {
                if (header.length() == 0) // exit loop if no more headers to parse
                    break;
		headers.addElement(header);   // build the vector headers
                String key = getKey(header);  // parse the header name
                if (key != null) {
                    keys.put(key, getField(header));  // parse the header value
                }
                header = recv(in);  // get next header
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * helper routine to send output stream over the http connection
     *
     * @param msg - String sent via out to http server
     * @param out - OutputStream msg is written to
     *
     * @throws IOException when a problem occurs with the write
     */
    private void send(OutputStream out, String msg) throws IOException {
	// create outputstreamwriter to write whole String
	OutputStreamWriter output = new OutputStreamWriter(out);

	output.write(msg, 0, msg.length());  // write to output stream
	output.flush();
    }

    /**
     * Helper routine to read a newline-terminated string from input stream
     *
     * @param in - inputstream to read from
     *
     * @throws IOException when a problem occurs with the read
     *
     */
    private String recv(InputStream in) throws IOException {
        String result = "";  // final result from read to be returned
        int c = in.read();   // read in initial char from inputstream

        while (c >= 0 && c != '\n') {
            if (c != '\r') {
                result += (char)c;
            }
            c = in.read();
        }
	//System.out.println("The results of the read = " + result);
        return result;
    }
}
