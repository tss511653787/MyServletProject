/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.gnat.util;

import java.io.*;
import java.util.*;

/**
 * This class provides a ResourceBundle for Gnat Tag Library Exception strings.
 *
 * @author <a href="mailto:sstirling@mediaone.net">Scott M. Stirling</a>
 */
public class GnatTagStrings extends ListResourceBundle
{
      public Object[][] getContents() {
                   return contents;
           }
           static final Object[][] contents = {
           // LOCALIZE THIS
                   // These names should match whatever you set their <tag-name>'s to in the TLD
                   {"deltree.tag", "deltree"},
                   {"fail.tag", "fail"},
                   {"gzip.tag", "gzip"},
                   {"gunzip.tag", "gunzip"},
                   {"ls.tag", "ls"},
                   {"mkdir.tag", "mkdir"},
                   {"touch.tag", "touch"},
                   {"tstamp.tag", "tstamp"},
                   {"mkdir.success", "Directory creation successful: "}, //miscellaneous message strings from here down
                   {"touch.success", "File creation successful: "}, 
                   {"touch.log.mod.time", "touch: Setting modification time for "},
           // END OF MATERIAL TO LOCALIZE
           };
}
