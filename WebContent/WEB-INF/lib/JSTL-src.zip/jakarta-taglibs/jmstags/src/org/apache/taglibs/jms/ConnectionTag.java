/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.jms;

import javax.jms.JMSException;
import javax.servlet.jsp.JspException;

import org.apache.commons.messenger.Messenger;
import org.apache.commons.messenger.MessengerManager;

/** Defines a JMS connection for use by other JMS tags.
  *
  * @author <a href="mailto:jstrachan@apache.org">James Strachan</a>
  * @version $Revision: 216790 $
  */
public class ConnectionTag extends AbstractTag implements ConnectionContext {

    /** The variable name to create */
    private String var;
        
    /** Stores the name of the map entry */
    private String name;

    /** The Messenger */
    private Messenger connection;

    // ConnectionContext interface
    //-------------------------------------------------------------------------                    
    public Messenger getConnection() {
        return connection;        
    }
    
    // Tag interface
    //-------------------------------------------------------------------------                    
    public int doStartTag() throws JspException {
        try {
            connection = MessengerManager.get( name );
        }
        catch (JMSException e) {
            throw new JspException( "Could not find JMS Connection named: " + name + ". Reason: " + e, e );
        }
        if ( var != null ) {
            pageContext.setAttribute( var, connection );
        }
        return EVAL_BODY_INCLUDE;
    }
    
    public void release() {
        name = null;
        var = null;
        connection = null;
    }
    
    // Properties
    //-------------------------------------------------------------------------                    
    
    /** Sets the name of the Destination
      */
    public void setName(String name) {
        this.name = name;
    }
    
    /** Sets the variable name to use for the Destination
      */
    public void setVar(String var) {
        this.var = var;
    }
}
