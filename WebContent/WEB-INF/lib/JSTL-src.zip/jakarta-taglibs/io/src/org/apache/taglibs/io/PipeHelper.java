/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.io;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.Reader;
import java.io.Writer;

import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

/** A collection of helper methods for pipelining data between tags.
  * 
  * @author <a href="mailto:james.strachan@metastuff.com">James Strachan</a>
  * @version $Revision: 216774 $
  */
public class PipeHelper {
    
    /** Size of the buffer used when piping a stream */
    protected static final int BUFFER_SIZE = 64 * 1024;
    
    /** Temporarily disable the closing of Readers */
    protected static final boolean CLOSE_READER = false;

    
    /** Uses the standard pipelining guidelines to produce a Reader
      * instance for the given object. 
      * The object can be either a Reader, an InputStream or a String.
      *
      * @return a Reader for the given input or null if the instance
      * could not be converted into a Reader.
      */
    public static Reader getReader(Object input) {
        if ( input instanceof Reader ) {
            return (Reader) input;
        }
        else if ( input instanceof InputStream ) {
            return new InputStreamReader( (InputStream) input );
        }
        else if ( input instanceof String ) {
            return new StringReader( (String) input );
        }
        return null;
    }
    
    /** Uses the standard pipelining guidelines to produce a Writer
      * instance for the given object. 
      * The object can be either a Writer or an InputStream.
      *
      * @return a Writer for the given input or null if the instance
      * could not be converted into a Writer.
      */
    public static Writer getWriter(Object output) {
        if ( output instanceof Writer ) {
            return (Writer) output;
        }
        else if ( output instanceof OutputStream ) {
            return new OutputStreamWriter( (OutputStream) output );
        }
        return null;
    }
    
    
    /** Pipes all the input from the given reader to the given writer. 
      * The reader will be closed whether an error occurs or not. 
      * Though the writer is left open.
      */
    public static void pipe(Reader reader, Writer writer) throws IOException {
        pipe( reader, writer, new char[ BUFFER_SIZE / 2 ] );
    }
    
    /** Pipes all the input from the given reader to the given writer. 
      * The reader will be closed whether an error occurs or not. 
      * Though the writer is left open.
      */
    public static void pipe(Reader reader, Writer writer, char[] buffer) throws IOException {
        try {
            while (true) {
                int size = reader.read( buffer );
                if ( size <= 0 ) {
                    return;
                }
                writer.write( buffer, 0, size );
            }
        }
        finally {
            if ( CLOSE_READER ) {
                try {
                    reader.close();
                }
                catch (Exception e) {
                }
            }
        }
    }
    
    /** Pipes all the input to the given output.
      * The input stream will be closed whether an error occurs or not. 
      * Though the output stream is left open is left open.
      */
    public static void pipe(InputStream input, OutputStream output) throws IOException {
        pipe( input, output, new byte[ BUFFER_SIZE ] );
    }
    
    
    /** Pipes all the input to the given output.
      * The input stream will be closed whether an error occurs or not. 
      * Though the output stream is left open is left open.
      */
    public static void pipe(InputStream input, OutputStream output, byte[] buffer) throws IOException {
        try {
            while (true) {
                int size = input.read( buffer );
                if ( size <= 0 ) {
                    return;
                }
                output.write( buffer, 0, size );
            }
        }
        finally {
            try {
                input.close();
            }
            catch (IOException e) {
            }
        }
    }
}
