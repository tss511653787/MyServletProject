/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 


package org.apache.taglibs.jndi;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import javax.naming.*;
import java.io.*;

/**
 *
 * @author  Danno Ferrin <shemnon@earthlink.net>
 * @version $Revision: 216819 $
 */
public class ListTag extends BodyTagSupport {

    private Context context;
    private String contextRef;
    private String nameId;
    private String classId;
    private String objId;
    private int nameScope = PageContext.PAGE_SCOPE;
    private int classScope = PageContext.PAGE_SCOPE;
    private int objScope = PageContext.PAGE_SCOPE;

    private String name;
    private Name nameObject;
    private boolean bindings;
    
    private NamingEnumeration nameEnum;
    private NameClassPair currentListing;
    
    /** Creates new ListTag */
    public ListTag() {
    }

    /** Getter for property context.
     * @return Value of property context.
     */
    public Context getContext() {
        return context;
    }

    /**
     * Setter for property context.
     * @param context New value of property context.
     */
    public void setContext(Context context) {
        this.context = context;
    }

    /**
     * Setter for property contextRef.
     * @param contextRef New value of property contextRef.
     */
    public void setContextRef(String contextRef) {
        this.contextRef = contextRef;
    }

    /**
     * Getter for property nameId.
     * @return Value of property nameId.
     */
    public String getNameId() {
        return nameId;
    }

    /**
     * Setter for property nameId.
     * @param nameId New value of property nameId.
     */
    public void setNameId(String nameId) {
        this.nameId = nameId;
    }

    /**
     * Setter for property nameScope.
     * @param nameScope New value of property nameScope.
     */
    public void setNameScope(String nameScope) {
        this.nameScope = decodeScope(nameScope);
    }

    /**
     * Getter for property classId.
     * @return Value of property classId.
     */
    public String getClassId() {
        return classId;
    }

    /**
     * Setter for property classId.
     * @param classId New value of property classId.
     */
    public void setClassId(String classId) {
        this.classId = classId;
    }

    /** 
     * Setter for property classScope.
     * @param classScope New value of property classScope.
     */
    public void setClassScope(String classScope) {
        this.classScope = decodeScope(classScope);
    }

    /**
     * Getter for property objId.
     * @return Value of property objId.
     */
    public String getObjId() {
        return objId;
    }

    /**
     * Setter for property objId.
     * @param objId New value of property objId.
     */
    public void setObjId(String objId) {
        this.objId = objId;
    }

    /** Setter for property objScope.
     * @param objScope New value of property objScope.
     */
    public void setObjScope(String objScope) {
        this.objScope = decodeScope(objScope);
    }

    /**
     * Getter for property name.
     * @return Value of property name.
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for property name.
     * @param name New value of property name.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for property nameObject.
     * @return Value of property nameObject.
     */
    public Name getNameObject() {
        return nameObject;
    }

    /**
     * Setter for property nameObject.
     * @param nameObject New value of property nameObject.
     */
    public void setNameObject(Name nameObject) {
        this.nameObject = nameObject;
    }

    /**
     * Getter for property bindings.
     * @return Value of property bindings.
     */
    public boolean getBindings() {
        return bindings;
    }

    /**
     * Setter for property bindings.
     * @param bindings New value of property bindings.
     */
    public void setBindings(boolean bindings) {
        this.bindings = bindings;
    }
    
    public int doStartTag() throws JspException {
        if( contextRef != null ) {
            context = null;
            Object o = pageContext.findAttribute(contextRef);
            if (o instanceof Context) {
                context = (Context)o;
            }
        }
        if (context == null) {
            throw new JspException("Context is not set for list itteration");
        }
        try {
            if (nameObject != null) {
                if (bindings) {
                    nameEnum = context.listBindings(nameObject);
                } else {
                    nameEnum = context.list(nameObject);
                }
            } else {
                if (bindings) {
                    nameEnum = context.listBindings(name);
                } else {
                    nameEnum = context.list(name);
                }
            } 
            
            if (nameEnum.hasMoreElements()) {
                return EVAL_BODY_TAG;
            } else {
                return SKIP_BODY;
            }
        } catch (NamingException ne) {
            throw new JspTagException("JNDI list tag could not list bindings: "+ne.getMessage());
        }
    }
    
    public void doInitBody() {
        currentListing = (NameClassPair) nameEnum.nextElement();
        if (nameId != null) {
            pageContext.setAttribute(nameId,
                    currentListing.getName(), nameScope);
        }
        if (classId != null) {
            pageContext.setAttribute(classId, 
                    currentListing.getClassName(), classScope);
        }
        if (bindings && (objId != null)) {
	    if (currentListing instanceof Binding) {
                pageContext.setAttribute(objId,
                    ((Binding)currentListing).getObject(), objScope);
	    } else {
                pageContext.setAttribute(objId, "Uh Oh, no Binding!", objScope);
            }
        }
    }
    
    public int doAfterBody() {
        if (nameEnum.hasMoreElements()) {
            currentListing = (NameClassPair) nameEnum.nextElement();
            if (nameId != null) {
                pageContext.setAttribute(nameId,
                        currentListing.getName(), nameScope);
            }
            if (classId != null) {
                pageContext.setAttribute(classId, 
                        currentListing.getClassName(), classScope);
            }
            if (bindings && (objId != null)) {
                if (currentListing instanceof Binding) {
                    pageContext.setAttribute(objId,
                        ((Binding)currentListing).getObject(), objScope);
	        } else {
                    pageContext.setAttribute(objId, "Uh Oh, no Binding!", objScope);
                }
            }
            return EVAL_BODY_TAG;
        } else {
            return SKIP_BODY;
        }
    }
    
    public int doEndTag() throws JspException {
        try {
            if (bodyContent != null) {
                bodyContent.writeOut(pageContext.getOut());
            }
        } catch (IOException ioe) {
            throw new JspException(ioe.toString());
        }
        if (nameId != null && nameScope != PageContext.REQUEST_SCOPE) {
            pageContext.removeAttribute(nameId, nameScope);
        }
        if (classId != null && classScope != PageContext.REQUEST_SCOPE) {
            pageContext.removeAttribute(classId, classScope);
        }
        if (bindings && (objId != null) && objScope != PageContext.REQUEST_SCOPE) {
            pageContext.removeAttribute(objId, objScope);
        }
        try {
             nameEnum.close();
        } catch (NamingException ne) {
            // we got what we wanted, it should be safe to ignore this
        }
        return EVAL_PAGE;
    }
    
    static int decodeScope(String scope) {
        if (scope.equalsIgnoreCase("page")) {
            return PageContext.PAGE_SCOPE;
        } else if (scope.equalsIgnoreCase("request")) {
            return PageContext.REQUEST_SCOPE;
        } else if (scope.equalsIgnoreCase("session")) {
            return PageContext.SESSION_SCOPE;
        } else if (scope.equalsIgnoreCase("application")) {
            return PageContext.APPLICATION_SCOPE;
        } else {
            return  -1;
        }
    }        
}
