/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;

import javax.servlet.ServletContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.Tag;

/** An abstract base class for a text based transformation tags which take some
  * input and produces some output. Both input and output can be specified via
  * attributes and scriplet expressions or via contained 'pipeline aware' tags.
  *
  * @author <a href="mailto:james.strachan@metastuff.com">James Strachan</a>
  * @version $Revision: 216774 $
  */
public abstract class TransformerTagSupport extends AbstractBodyTag implements PipeConsumer {

    protected static final boolean CLOSE_READER = false;
    
    
    /** Reader to take input from */    
    private Reader reader;
    
    /** Writer to output to */
    private Writer writer;
    
    public TransformerTagSupport() {
    }
    
    
    // BodyTag interface
    //-------------------------------------------------------------------------                    
    public int doStartTag() throws JspException {
        return EVAL_BODY_TAG;
    }
    
    public int doAfterBody() throws JspException {
        BodyContent body = null;
        if ( reader == null ) {
            body = getBodyContent();
            reader = new StringReader( body.getString() );
        }
        if ( writer == null ) {
            writer = getBodyContent().getEnclosingWriter();
        }
        try {
            transform( reader, writer );
        }
        catch (IOException e) {
            handleException(e);
        }
        finally {
            if ( CLOSE_READER ) {
                try {
                    reader.close();
                }
                catch (Exception e) {
                }
            }
            reader = null;
            writer = null;
            if ( body != null ) {
                body.clearBody();
            }
        }
        return EVAL_PAGE;
    }
    
    public void release() {
        super.release();
        reader = null;
        writer = null;
    }
    
    // PipeConsumer interface
    //-------------------------------------------------------------------------                            
    public void setReader(Reader reader) {
        this.reader = reader;
    }

    // PipeProducer interface
    //-------------------------------------------------------------------------                        
    public void setWriter(Writer writer) {
        this.writer = writer;
    }
    
    // Implementation methods
    //-------------------------------------------------------------------------                            
    protected PipeConsumer getConsumer() {
        return (PipeConsumer) findAncestorWithClass( this, PipeConsumer.class );
    }

    /** Perform some arbitrary transformation */
    protected abstract void transform(
        Reader reader, 
        Writer writer
    ) throws IOException, JspException;
}    
