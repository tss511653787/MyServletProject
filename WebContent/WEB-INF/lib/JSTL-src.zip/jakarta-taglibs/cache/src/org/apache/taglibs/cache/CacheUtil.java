/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 

package org.apache.taglibs.cache;

import javax.servlet.jsp.PageContext;

/**
 * <p>Contains static methods that can be used to save and retrieve
 * information used to retrieve appropriate caches and to 
 * configure the runtime behavior of the Cache Taglib.</p>
 *
 * @author Shawn Bayern
 */

public class CacheUtil {

    //*********************************************************************
    // Constants

    private static final String CACHE_PAGE = "org.apache.taglibs.cache.page";
    private static final String CACHE_REQUEST = "org.apache.taglibs.cache.request";
    private static final String CACHE_SESSION = "org.apache.taglibs.cache.session";
    private static final String CACHE_APPLICATION = "org.apache.taglibs.cache.application";

    private static final String CACHES_PREFIX = "caches.";
    private static final String LIFETIME = "lifetime";
    private static final String SIZE = "size";

    private static final int DEFAULT_SIZE = 65536;
    private static final int DEFAULT_LIFETIME = 300;

    //*********************************************************************
    // Public methods

    /**
     * Retrieves the size of the cache, given a particular scope and
     * a context.
     */ 
    public static int getCacheSize(int scope, PageContext pageContext) {
        String attribute = getAttributeName(scope, SIZE);
        Number n = (Number)pageContext.getAttribute(attribute, scope);
        if (n == null) {
            return DEFAULT_SIZE;
        } else {
            return n.intValue();
        }
    }

    /**
     * Retrieves the lifetime of items in the cache, given a particular
     * scope and a context.
     */ 
    public static int getCacheLifetime(int scope, PageContext pageContext) {
        String attribute = getAttributeName(scope, LIFETIME);
        Number n = (Number)pageContext.getAttribute(attribute, scope);
        if (n == null) {
            return DEFAULT_LIFETIME;
        } else {
            return n.intValue();
        }
    }

    /**
     * Sets a particular cache size to use for new caches in the
     * given scope.
     */
    public static void setCacheSize(int size, int scope, PageContext ctx) {
        String attribute = getAttributeName(scope, SIZE);
        ctx.setAttribute(attribute, new Integer(size), scope);
    }

    /**
     * Sets a particular cache lifetime to use for new caches in the
     * given scope.
     */
    public static void setCacheLifetime(int lifetime, int scope, PageContext ctx) {
        String attribute = getAttributeName(scope, LIFETIME);
        ctx.setAttribute(attribute, new Integer(lifetime), scope);
    }

    /**
     * Retrieves (and creates if necessary) an appropriate LRUCache
     * given a scope, name, and context.
     */
    public static LRUCache getCache(int scope, String name, PageContext ctx) {
        String att = getAttributePrefixForScope(scope) + CACHES_PREFIX + name;
        LRUCache l = (LRUCache)ctx.getAttribute(att, scope);
        if (l == null) {
            l = new LRUCache(getCacheSize(scope, ctx), getCacheLifetime(scope, ctx));
            ctx.setAttribute(att, l, scope);
        }
        return l;
    }

    /**
     * Invalidates an entire cache
     */
    public static void invalidateCache(int scope, String name, PageContext pageContext) {
        String att = getAttributePrefixForScope(scope) + CACHES_PREFIX + name;
        pageContext.removeAttribute(att, scope);
    }

    /**
     * Invalidates an individual cache entry (key)
     */
    public static void invalidateCachedItem(int scope, String name, String key, PageContext pageContext) {
        LRUCache l = getCache(scope, name, pageContext);
        if (l == null) {
            return; // nothing to do
        }
        l.remove(key);
    }


    //*********************************************************************
    // Private utility methods

    private static String getAttributeName(int scope, String variable) {
        return getAttributePrefixForScope(scope) + variable;
    }

    private static String getAttributePrefixForScope(int scope) {
        switch(scope) {
        case PageContext.PAGE_SCOPE:
            return CACHE_PAGE + ".";
        case PageContext.REQUEST_SCOPE:
            return CACHE_REQUEST + ".";
        case PageContext.SESSION_SCOPE:
            return CACHE_SESSION + ".";
        case PageContext.APPLICATION_SCOPE:
            return CACHE_APPLICATION + ".";
        default:
            throw new IllegalArgumentException("unknown scope");
        }
    }    
}
