/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.regexp;

import java.util.*;
import org.apache.oro.text.*;
import org.apache.oro.text.perl.*;
import org.apache.oro.text.regex.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * JSP Tag <b>match</b>, used to implement a perl style
 * match on the text.
 * <p>
 * The body of the tag iterates through each match found.
 * The normal &lt;jsp:getProperty/&gt; can be used to get
 * the match results using the id of the <b>match</b> tag
 * script variable.
 * <p>
 * The attribute <b>text</b> must be set to the id of a
 * <b>text</b> tag, and the <b>regexp</b> attribute must
 * be set to the id of a <b>regexp</b> tag.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;match&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.regexp.MatchTag&lt;/tagclass&gt;
 * &lt;bodycontent&gt;JSP&lt;/bodycontent&gt;
 * &lt;info&gt;Uses the regexp to find matches in text, loops for each match found.&lt;/info&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;id&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;text&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;regexp&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 * </pre>
 *
 * @see RegexpTag
 * @see TextTag
 * @see RegexpData
 * @see TextData
 *
 * @author Glenn Nielsen
 */

public class MatchTag extends BodyTagSupport
{
    private String regexpid = null;
    private String textid = null;
    private Perl5Util perl = new Perl5Util(RegexpData.getPatternCache());
    private PatternMatcherInput pmi = null;
    private RegexpData rd = null;

    /**
     * Setup to loop through matches found in the text using regexp
     *
     * @return EVAL_BODY_TAG if a match is found, BODY_SKIP if no matches are found
     */
    public final int doStartTag() throws JspException
    {
	TextData td = (TextData)pageContext.getAttribute(textid,PageContext.PAGE_SCOPE);
	if( td == null )
	    throw new JspException(
		"regexp tag match could not find text tag with id: " +
		textid);
	pmi = new PatternMatcherInput(td.getText());

        rd = (RegexpData)pageContext.getAttribute(regexpid,PageContext.PAGE_SCOPE);
        if( rd == null )
            throw new JspException(
                "regexp tag match could not find regexp tag with id: " +
                regexpid);
	if( !perl.match(rd.getRegexp(),pmi) )
	    return SKIP_BODY;

	pageContext.setAttribute(id,this,PageContext.PAGE_SCOPE);

	return EVAL_BODY_TAG;
    }

    /** 
     * Method called at end of each iteration of the match tag
     *
     * @return EVAL_BODY_TAG if there is another string match, or BODY_SKIP if there are no more strings
     */
    public final int doAfterBody() throws JspException
    {
	if( !perl.match(rd.getRegexp(),pmi) )
	    return SKIP_BODY;
	return EVAL_BODY_TAG;
    }

    /**
     * Method called at end of match Tag
     *
     * @return EVAL_PAGE
     */
    public final int doEndTag() throws JspException
    {
        if( id != null && id.length() > 0 )
            pageContext.removeAttribute(id,PageContext.PAGE_SCOPE);
	try {
	    if(bodyContent != null)
		bodyContent.writeOut(bodyContent.getEnclosingWriter());
	} catch(java.io.IOException e) {
	    throw new JspException("IO Error: " + e.getMessage());
	}
	return EVAL_PAGE;
    }

    /*
     * Set the required attribute <b>regexp</b>
     *
     * @param String name of regexp script variable
     */
    public final void setRegexp(String str)
    {   
	regexpid = str;
    }

    /*
     * Set the required attribute <b>text</b>
     *
     * @param String name of text script variable
     */
    public final void setText(String str)
    {               
        textid = str;
    }

    /**
     * Returns the entire string that was matched on
     * using &lt;jsp:getProperty name=<i>"id"</i> property="match"/&gt;
     * 
     * @return String - entire text of match
     */
    public final String getMatch() 
    {
        return perl.toString();
    }

    /**
     * Returns the string preceding the current match
     * using &lt;jsp:getProperty name=<i>"id"</i> property="preMatch"/&gt;
     *
     * @return String - text preceding match
     */
    public final String getPreMatch()
    {
	return perl.preMatch();
    }

    /**
     * Returns the string after the current match                                              
     * using &lt;jsp:getProperty name=<i>"id"</i> property="postMatch"/&gt;
     * 
     * @return String - text after the match
     */
    public final String getPostMatch() 
    {
        return perl.postMatch();
    }

    /**
     * Returns the string for the group parenthesized number
     *
     * @return String - for group parenthesized number
     */
    public final String getGroup(int i)
    {
	String group = perl.group(i);
	if( group == null )
	    return "";
	return group;
    }

}
