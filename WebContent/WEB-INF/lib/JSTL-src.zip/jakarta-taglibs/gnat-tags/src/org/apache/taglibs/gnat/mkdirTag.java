/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.gnat;

import org.apache.taglibs.gnat.util.*;
import javax.servlet.ServletContext;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;
import java.util.*;

public class mkdirTag extends TagSupport
{
    //Note: in Ant's Mkdir task, dir is a File object passed in from a client class
    private File _f;
    private String dir = "";
    private boolean clobber= false;
    private ResourceBundle gnatRB = ListResourceBundle.getBundle("org.apache.taglibs.gnat.util.GnatTagStrings");
    private ResourceBundle gnatERB = ListResourceBundle.getBundle("org.apache.taglibs.gnat.util.GnatExceptionStrings");
    
    public void setDir(String dir)
    {
        this.dir = dir;
    }
    
    public void setClobber(boolean clobber)
    {
        this.clobber = clobber;
    }
    
    
    public int doStartTag() throws JspException
    {
        _f = new File(dir);
        return SKIP_BODY;
    }
    
    public int doEndTag() throws JspException
    {
        
        if (_f == null) 
        {
            throw new JspTagException( gnatRB.getString("mkdir.tag") + ": " +
                                       gnatERB.getString("empty.dir.attribute") );
        }
        
        ServletContext ctx = pageContext.getServletContext();
        if (clobber) //default is clobber == false
        {
            if (_f.exists()) 
            {   // log that we are overwriting the directory . . .
                ctx.log(gnatRB.getString("mkdir.tag") + ": " +"Overwriting dir " + _f.toString());
                try {    // . . . and delete it before recreating it..
                    FileUtil.forceDelete(_f);
                }
                catch(IOException ioe) {
                    throw new JspTagException( gnatRB.getString("mkdir.tag") + ": " +
                                               ioe.getMessage() );
                }
            }

            boolean result = _f.mkdirs();
            if (result == false) 
            {
                String msg = gnatRB.getString("mkdir.tag") + ": " + 
                             gnatERB.getString("unknown.mkdir.fail") + 
                             _f.getAbsolutePath(); 
                
                throw new JspTagException(msg);
            }
            ctx.log( gnatRB.getString("mkdir.tag") + ": " +
                     gnatRB.getString("mkdir.success") + 
                     _f.getAbsolutePath() );
        }
        else if(!clobber) //default is clobber == false
        {
            if (_f.exists()) // throw an exception if the file exists
            {
                throw new JspTagException( gnatRB.getString("mkdir.tag") + ": " +
                                           gnatERB.getString("duplicate.mkdir.fail") + 
                                           _f.getAbsolutePath() );
            }
            else
            {
            
                boolean result = _f.mkdirs();
                if (result == false) 
                {
                    String msg = gnatRB.getString("mkdir.tag") + ": " + 
                                 gnatERB.getString("unknown.mkdir.fail") + 
                                 _f.getAbsolutePath(); 
                
                    throw new JspTagException(msg);
                }
                ctx.log( gnatRB.getString("mkdir.tag") + ": " +
                         gnatRB.getString("mkdir.success") + 
                         _f.getAbsolutePath() );
            }
        }

        return EVAL_PAGE;
    }
    
    public String getDir() { return dir; }
    public boolean getClobber() { return clobber; }
}
