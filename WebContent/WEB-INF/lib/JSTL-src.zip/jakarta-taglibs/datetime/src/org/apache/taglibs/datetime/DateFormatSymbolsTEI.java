/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.datetime;

import javax.servlet.jsp.tagext.TagExtraInfo;
import javax.servlet.jsp.tagext.VariableInfo;
import javax.servlet.jsp.tagext.TagData;

/**
 * TagExtraInfo for <b>dateFormatSymbols</b> tag, allows use of standard
 * &lt;jsp:getProperty/&gt; with the <b>dateFormatSymbols</b> tag script
 * variable id.
 * 
 * @see DateFormatSymbolsTag
 *
 * @author <a href="mailto:wigor@bigmir.net">Kozlov Igor</a>
 */
public class DateFormatSymbolsTEI extends TagExtraInfo {

    public VariableInfo[] getVariableInfo(TagData data) {
        String varName = data.getAttributeString("id");
        if (varName == null) {
            return new VariableInfo[]{
            };
        } else {
            return new VariableInfo[]{
                new VariableInfo(varName,
                        "java.text.DateFormatSymbols",
                        true,
                        VariableInfo.AT_BEGIN),
            };
        }
    }


}
