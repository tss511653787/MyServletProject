/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.gnat;

import org.apache.taglibs.gnat.util.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;
import java.util.*;

public class lsTag extends BodyTagSupport
{
    private String dir = "";
    private File _f;
    private ResourceBundle gnatRB = ListResourceBundle.getBundle("org.apache.taglibs.gnat.util.GnatTagStrings");
    private ResourceBundle gnatERB = ListResourceBundle.getBundle("org.apache.taglibs.gnat.util.GnatExceptionStrings");
    private String item = null;
    private String[] _files = null;
    private int _i = 0;
        
    public void setDir(String dir) {
        this.dir = dir;
    }
    
    public void setItem(String item) {
        this.item = item;
    }
    
    /**
     * Gets the file listing and kicks off the loop through all the file names 
     * in a directory.
     *
     * @return SKIP_BODY if no items are found, EVAL_BODY_TAG if items exist.
     */
    public final int doStartTag() throws JspException
    {
        if (!dir.equals(""))
        {   // Get directory using absolute file name (add capability for relative files?)
            _f = FileUtil.resolveFile( null, dir );
             
            try
            {
                _files = _f.list();
    	        if( _files == null || !( _files.length > 0 ) )
                {
	                return SKIP_BODY;
                }
                else
                {
    	            item = getNext( _files, _i );
                    _i++;
                }
                
                pageContext.setAttribute( id, this ); 
            }
            catch(Exception e)
            {
                throw new JspTagException(gnatRB.getString("ls.tag") + ": " + e.getMessage());
            }
	        return EVAL_BODY_TAG;
        }
        else
        {
            throw new JspTagException(gnatRB.getString("ls.tag") + ": " + gnatERB.getString("empty.dir.attribute"));
        }
    }

    /**
     * Takes control of the loop from doStartTag(),  It accesses the
     * variables set up there and sets the logic for the rest of the loop.
     *
     * @return EVAL_BODY_TAG if there is another list item, or SKIP_BODY if there are no more.
     */
    public final int doAfterBody() throws JspException
    {
	    if( _i < _files.length ) {
    	    item = getNext( _files, _i );
            _i++;
            return EVAL_BODY_TAG;
        }
        else { 
            return SKIP_BODY; 
        }
    }

    /**
     * Method called at end of Tag to write out the response.
     * @return EVAL_PAGE
     */
    public final int doEndTag() throws JspException
    {
	    try {
	        if( bodyContent != null )
            bodyContent.writeOut( bodyContent.getEnclosingWriter() );
        } 
        catch(IOException ioe)
        {
            throw new JspException( gnatRB.getString("ls.tag") + ": " + ioe.getMessage() );
        }
        return EVAL_PAGE;
    }
   
    /**
    * Returns a String from a given array and index. Called from doStartTag and
    * and doAfterBody.
    */ 
    private String getNext(String array[], int index)
    {
        String s = array[index];
        return s;
    }

    /**
     * Remove the id variable after ls tag is finished.
     */
    public final void release()
    {
	    if( id != null )
	    pageContext.removeAttribute( id, PageContext.PAGE_SCOPE );
        _i = 0;
    }

    /* Put tag attribute accessors down here, out of the way, since they're more for 
       JavaBean completeness than programmer use. 
     */
    public String getDir() { return dir; }
    public String getItem() { return item; }
}
