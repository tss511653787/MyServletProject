/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 

package org.apache.taglibs.jndi;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import javax.naming.*;
import javax.naming.directory.*;

import java.io.*;

/**
 *
 * @author  Danno Ferrin <shemnon@earthlink.net>
 * @version $Revision: 216819 $
 */
public class SearchTag extends BodyTagSupport {

    private int scope = PageContext.PAGE_SCOPE;
    private String attributes;
    private String attributeSeparator = ",";
    private SearchControls controls;
    private DirContext context;
    private String contextRef;
    private String filter;
    private NamingEnumeration nameEnum;
    private SearchResult currentResult;
    private String name = "";
    private Name nameObject;

    /** Creates new SearchTag */
    public SearchTag() {
    }

    public void setPageContext(PageContext pc) {
        controls = new SearchControls();
        super.setPageContext(pc);
    }

    /**
     * Setter for property scope.
     * @param Scope New value of property scope.
     */
    public void setScope(String scope) {
        this.scope = decodeScope(scope);
    }

    /**
     * Getter for property context.
     * @return Value of property context.
     */
    public DirContext getContext() {
        return context;
    }

    /**
     * Setter for property context.
     * @param context New value of property context.
     */
    public void setContext(DirContext context) {
        this.context = context;
    }

    /**
     * Setter for property contextRef.
     * @param contextRef New value of property contextRef.
     */
    public void setContextRef(String contextRef) {
        this.contextRef = contextRef;
    }

    /**
     * Getter for property `.
     * @return Value of property name.
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for property name.
     * @param name New value of property name.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for property nameObject.
     * @return Value of property nameObject.
     */
    public Name getNameObject() {
        return nameObject;
    }

    /**
     * Setter for property nameObject.
     * @param nameObject New value of property nameObject.
     */
    public void setNameObject(Name nameObject) {
        this.nameObject = nameObject;
    }

    /**
     * Getter for property filter.
     * @return Value of property filter.
     */
    public String getFilter() {
        return filter;
    }

    /**
     * Setter for property filter.
     * @param filter New value of property filter.
     */
    public void setFilter(String filter) {
        this.filter = filter;
    }

    /**
     * Getter for property countLimit.
     * @return Value of property countLimit.
     */
    public long getCountLimit() {
        return controls.getCountLimit();
    }

    /**
     * Setter for property countLimit.
     * @param countLimit New value of property countLimit.
     */
    public void setCountLimit(long countLimit) {
        controls.setCountLimit(countLimit);
    }

    /**
     * Getter for property derefLink.
     * @return Value of property derefLink.
     */
    public boolean getDerefLink() {
        return controls.getDerefLinkFlag();
    }

    /**
     * Setter for property derefLink.
     * @param derefLink New value of property derefLink.
     */
    public void setDerefLink(boolean derefLink) {
        controls.setDerefLinkFlag(derefLink);
    }

    /**
     * Getter for property attributes.
     * @return Value of property attributes.
     */
    public String getAttributes() {
        return attributes;
    }

    /**
     * Setter for property attributes.
     * @param attributes New value of property attributes.
     */
    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }

    /**
     * Getter for property attributeSeparator.
     * @return Value of property attrbuteSeparator.
     */
    public String getAttributeSeparator() {
        return attributeSeparator;
    }

    /**
     * Setter for property attributeSeparator.
     * @param attrbuteSeparator New value of property attrbuteSeparator.
     */
    public void setAttributeSeparator(String attributeSeparator) {
        this.attributeSeparator = attributeSeparator;
    }

    /**
     * Getter for property bindings.
     * @return Value of property bindings.
     */
    public boolean getBindings() {
        return controls.getReturningObjFlag();
    }

    /**
     * Setter for property bindings.
     * @param bindings New value of property bindings.
     */
    public void setBindings(boolean bindings) {
        controls.setReturningObjFlag(bindings);
    }

    /**
     * Getter for property searchScope.
     * @return Value of property searchScope.
     */
    public String getSearchScope() {
        return decodeSearchScope(controls.getSearchScope());    
    }

    /**
     * Setter for property searchScope.
     * @param searchScope New value of property searchScope.
     */
    public void setSearchScope(String searchScope) {
        controls.setSearchScope(decodeSearchScope(searchScope));
    }

    /**
     * Getter for property timeLimit.
     * @return Value of property timeLimit.
     */
    public int getTimeLimit() {
        return controls.getTimeLimit();
    }

    /**
     * Setter for property timeLimit.
     * @param timeLimit New value of property timeLimit.
     */
    public void setTimeLimit(int timeLimit) {
        controls.setTimeLimit(timeLimit);
    }
    
    public int doStartTag() throws JspException {
        // Initialize invocation variables
        nameEnum = null;

        if( contextRef != null ) {
            context = null;
            Object o = pageContext.findAttribute(contextRef);
            if (o instanceof DirContext) {
                context = (DirContext) o;
            } else if (o instanceof Context) {
                try {
                    // attempt a blank lookup
                    o = ((Context)o).lookup("");
                    if (o instanceof DirContext) {
                        context = (DirContext) o;
                    }
                } catch (NamingException ne) {
                    // oh well, it failed, toss it out
                }
            }
        }
        if( context == null ) {
            throw new JspException("JNDI search tag could not find a context");
        }
        String[] attrs = null;
        if (attributes != null) {
            if (attributes.length() == 0) {
                attrs = new String[0];
            } else {
                int count = 1;
                int i=0, j=0, size = attributeSeparator.length();
                while ((j=attributes.indexOf(attributeSeparator, i)) != -1) {
                    count++;
                    i = j + size;
                }
                attrs = new String[count];
                count = 0;
                i = 0;
                while ((j=attributes.indexOf(attributeSeparator, i)) != -1) {
                    attrs[count] = attributes.substring(i, j);
                    count++;
                    i = j + size;
                }
                attrs[count] = attributes.substring(i);
            }
        }
        
        controls.setReturningAttributes(attrs);

        try {
            if (nameObject != null) {
                nameEnum = context.search(nameObject, filter, controls);
            } else {
                nameEnum = context.search(name, filter, controls);
            }
        } catch (NamingException ne) {
            throw new JspException("JNDI search tag failed: "+ne.getMessage());
        }
        
        if (nameEnum.hasMoreElements()) {
            return EVAL_BODY_TAG;
        } else {
            return SKIP_BODY;
        }
    }
    
    public void doInitBody() {
        currentResult = (SearchResult) nameEnum.nextElement();
        if (getId() != null) {
            pageContext.setAttribute(getId(),
                    currentResult, scope);
        }
    }
        
    public int doAfterBody() {
        if (! nameEnum.hasMoreElements()) {
            return SKIP_BODY;
        } else {
            currentResult = (SearchResult) nameEnum.nextElement();
            if (getId() != null) {
                pageContext.setAttribute(getId(),
                        currentResult, scope);
            }
            return EVAL_BODY_TAG;
        }
    }
    
    public int doEndTag() throws JspException {
        try {
            if (bodyContent != null) {
                bodyContent.writeOut(pageContext.getOut());
            }
        } catch (IOException ioe) {
            throw new JspException(ioe.toString());
        }
        try {
            nameEnum.close();
        } catch (NamingException ne) {
            throw new JspException(ne.toString());
        }
        return EVAL_PAGE;
    }
    
    public static int decodeSearchScope(String scope) {
        // a better way would be to pop a hashtable with Integer as value
        if ("object_scope".equalsIgnoreCase(scope) || 
            "object".equalsIgnoreCase(scope)) {
            return SearchControls.OBJECT_SCOPE;
        } else if ("onelevel_scope".equalsIgnoreCase(scope) ||
                   "onelevel".equalsIgnoreCase(scope)) {
            return SearchControls.ONELEVEL_SCOPE;
        } else if ("subtree_scope".equalsIgnoreCase(scope) ||
                   "subtree".equalsIgnoreCase(scope)) {
            return SearchControls.SUBTREE_SCOPE;
        } else {
            return -1;
        }
    }
    
    public static String decodeSearchScope(int scope) {
        switch (scope) {
            case SearchControls.OBJECT_SCOPE:
                return "OBJECT_SCOPE";
            case SearchControls.ONELEVEL_SCOPE:
                return "ONELEVEL_SCOPE";
            case SearchControls.SUBTREE_SCOPE:
                return "SUBTREE_SCOPE";
            default:
                return null;
        }
    }

    public static int decodeScope(String scope) {
        if (scope.equalsIgnoreCase("request")) {
            return PageContext.REQUEST_SCOPE;
        } else if (scope.equalsIgnoreCase("session")) {
            return PageContext.SESSION_SCOPE;
        } else if (scope.equalsIgnoreCase("application")) {
            return PageContext.APPLICATION_SCOPE;
        } else {
            return PageContext.PAGE_SCOPE;
        }
    }
}
