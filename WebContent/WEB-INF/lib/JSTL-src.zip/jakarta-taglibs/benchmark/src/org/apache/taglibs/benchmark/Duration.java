/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.apache.taglibs.benchmark;

import java.io.*;
import javax.servlet.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 *
 *  A tag handler for the &lt;benchmark:duration&gt; tag, which determines
 *  how long it takes to compute its body (minus the sections of its body
 *  enclosed in &lt;benchmark:exclude&gt; ... &lt;/benchmark:exclude&gt;).
 *
 *  @version 0.90
 *  @author Shawn Bayern
 */

public class Duration extends BodyTagSupport {

    private long repeat = 1;		// number of repetitions
    private boolean output = false;	// do we output our contents?

    private long start, end;		// our own start and end times
    private boolean running;		// is our timer currently running?
    private long exclude;		// time to subtract from timer
    private long exStart;		// start of exclusion timer (tmp)
    
    public void release() {
	init();
    }

    public int doStartTag() throws JspException {
	start = System.currentTimeMillis();
	running = true;

	return EVAL_BODY_TAG;
    }

    public int doEndTag() throws JspException {
	try {
	    // first, stop the clock
	    end = System.currentTimeMillis();
	    running = false;

	    // next, output the body contents if appropriate
	    if (output)
		getPreviousOut().write(getBodyContent().getString());

	    // finally, output duration
	    pageContext.getOut().print(end - start - exclude);

	} catch (IOException ex) {
	    throw new JspTagException(ex.getMessage());
	}
	return EVAL_PAGE;
    }

    public int doAfterBody() throws JspException {
	if (--repeat > 0)
	    return EVAL_BODY_TAG;
	else
	    return SKIP_BODY;
    }

    /** Temporarily pauses our timer, which must already be running. */
    public void pauseTimer() throws JspTagException {
	if (!running) {
	    /*
	     * Display an error message customized for the common case,
	     * since this situation is possible but erroneous.  I've
	     * somewhat arbitrarily caught the error here instead of in
	     * <exclude> itself on the premise that if other tags are
	     * plugged in, we can localize this handling in the parent class.
	     * This may be stupid, but it's 5:16 in the morning, so what
	     * do I know?
	     */
	    throw new JspTagException(
		"can't &lt;exclude&gt; an already excluded section "
		+ "or otherwise pause a paused &lt;duration&gt; timer");
	}

	// start a separate exclusion timer
	exStart = System.currentTimeMillis();
	running = false;
    }

    /** Restarts our timer, which must already be paused. */
    public void restartTimer() throws JspTagException {
	if (running) {
	    // shouldn't happen unless new custom tags are added later
	    throw new JspTagException(
		"unexpected use of Duration.restartTimer() on active clock");
	}

	// end the current exclusion timer and compute exclusion
	long exEnd = System.currentTimeMillis();
	exclude += exEnd - exStart;
	running = true;
    }

    /** Initializes the timer. */
    private void init() {
	start = end = exclude = exStart = 0;
	repeat = 1;
	running = output = false;
    }


    // accessors

    public void setRepeat(long x) throws JspTagException {
	if (x < 0)
	    throw new JspTagException(
		"'repeat' in &lt;benchmark:duration&gt; cannot be negative");
	repeat = x;
    }

    public long getRepeat() {
	return repeat;
    }

    public void setOutput(boolean x) {
	output = x;
    }

    public boolean getOutput() {
	return output;
    }
}
