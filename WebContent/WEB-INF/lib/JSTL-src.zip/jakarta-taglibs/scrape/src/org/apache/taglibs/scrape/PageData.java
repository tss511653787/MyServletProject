/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.scrape;

import java.util.*;
import java.io.*;
import java.net.*;
import javax.servlet.jsp.*;
import sun.misc.BASE64Encoder;
import org.apache.oro.text.regex.*;

/**
 * PageData - An object used to store information about a scrape done by the 
 *            tags in the scrape package.
 *
 * @author Rich Catlett
 *
 * @version 1.0
 *
 */
public class PageData {

    /**
     * static HashMap holds all of the pagedata objects keyed to the url
     */
    public static HashMap pageurls = new HashMap();
    /**
     * static object used for synchronization
     */
    private static Object O = new Object();
    /**
     *stores data on each scrape, the data is stored in the order of the scrape
     */
    private HashMap scrapes = new HashMap();
    /**
     * boolean flag tells object that new scrapes for this page have been added
     */
    private boolean newflag;
    /**
     * boolean flag that marks if a change has been made to the flags in 
     * a scrape data object
     */
    private boolean changeflag;
    /**
     * Boolean object used to synchronize scrapes and it keeps track of when a
     * scrape is occuring
     */
    private Boolean scraping = new Boolean(false);
    /**
     * time the last scrape occured determines if page needs to be requested
     * again
     */
    private long lastscrape = 0;
    /**
     * PageContext object for the calling JSP page used to access the
     * ServletContext for logging error to the server
     */
    private PageContext pagecontext;
    // the following two variables are needed because the start method of 
    // Thread cannot throw a JspException
    /**
     * flag marks if a MalformedPatternException was thrown in scrape()
     */
    private boolean exception;
    /**
     * if an exception was thrown holds info on the error
     */
    private String exceptiontext;
    /**
     * thread that gets the requested page and then runs the scrape on the page
     */
    private Page page;
    /**
     * the port to use for the proxy connection
     */
    private int pport =-1;
    /**
     * the proxy server to use for the connection
     */
    private String pserver = null;
    /**
     * auth string for basic authentication to the proxy server username:password
     */
    private String auth = null;
    /**
     * boolean value determines if the connection to to travel via a secure
     * connection
     */
    private boolean ssl = false;
    /**
     * password to the client keystore for ssl client side authentication
     */
    private String sslclientpass = null;
    /**
     * list of names extra headers to add
     */
    private ArrayList name = new ArrayList(10);
    /**
     * list of values of extra headers to add
     */
    private ArrayList value = new ArrayList(10);

    /**
     * constructor for the class simply creates an instance of the PageData
     * object
     */
    public PageData() {}

    /**
     * method checks the static HashMap pageurls for the given url if it exists
     * it is returned, otherwise a new pagedata object is created and added
     * to the HashMap pageurls
     *
     * @param url  the url of the page given in the calling PageTag
     * @param port  the port to use for the connection to the proxy server
     * @param server  the proxy server
     * @param secure  is the link going over https
     * @param name  user name for authentication
     * @param pass  password for authentication
     *
     * @return a PageData object either newly created or one already in
     *         existence
     */
    public static PageData getPage(String url, int port, String server,
				   String name, String pass) {
         //public static PageData getPage(String url, int port, String server,
	 //   boolean ssl, String name, String pass, String sslpass) {
	PageData pagedata;

	if((pagedata = (PageData)pageurls.get(url)) == null) {
	    synchronized(O) {
	        if(pagedata == null) {
	            pagedata = new PageData(); // create new pagedata object
		    // set time of last scrape to current system time
	            pagedata.setLastScrape(new Date().getTime());
		    // set the proxyport and proxy server for this connection
		    pagedata.setProxyPort(port);
		    pagedata.setProxyServer(server);
		    pagedata.setAuth(name, pass);
		    /*
		    // set secure for the connection
		    pagedata.setSSL(ssl);
		    // set the keystore password for client side authentication
		    pagedata.setClientPass(sslpass);
		    // if secure == true set system property so that https will be
		    // understood
		    if (ssl)
			System.setProperty("java.protocol.handler.pkgs", 
					   "com.sun.net.ssl.internal.www.protocol");
		    */
                    // add pagedata object to static Hashmap
	            pageurls.put(url, pagedata);
		}
	    }
	}
	return pagedata;
    }

    /**
     * method to add an object to the HashMap scrapes, it first checks to see
     * if the object already exists
     *
     * @param id  unique identifier of the scrape the following attributes
     *            define
     * @param begin  beginning anchor for the scrape refered to by id
     * @param end  ending anchor for the scrape refered to by id
     * @param anchors  boolean flag that determines if begin and end anchors are
     *                 part of the result
     * @param strip  boolean flag that determines if tags are to be striped from
     *               the result
     *
     * @return a boolean value, true if a new scrape has been added else false
     */
    public final synchronized void setScrape(String id, String begin, 
		 String end, String anchors, String strip) throws JspException {

	ScrapeData scrape;  // used to test for equality of ScrapeData objects
	// boolean objects used to check if a flag value has been changed
	Boolean checkvalstrip;
	Boolean checkvalanchors;

	// check to see if this scrape already exists
	if((scrape = (ScrapeData)scrapes.get(id)) == null) {
	    // scrape does not already exist
	    scrape = new ScrapeData(); // create new scrapedata object
	    // set the attributes of the new scrapedata object
	    scrape.setBegin(begin);
	    scrape.setEnd(end);
	    if (anchors != null)
		scrape.setanchorsFlag(anchors);
	    if (strip != null)
		scrape.setstripFlag(strip);

            scrapes.put(id, scrape);  // add scrape to HashMap scrapes
	    newflag = true; // a new scrape has been added to this page
	} else if (((scrape.getBegin().compareTo(begin)) != 0) || 
                   ((scrape.getEnd().compareTo(end)) != 0)) { 
            // the two scrapedata objects are different	    
            throw new JspException ("scrape id " + id + " is already in use");
	} else if (((scrape.getBegin().compareTo(begin)) == 0) || 
                   ((scrape.getEnd().compareTo(end)) == 0)) {
	    // set check objects so that boolean can be compared to String
	    checkvalstrip = new Boolean(strip);
	    checkvalanchors = new Boolean(anchors);

	    // scrape is old scrape check to see if any flags have been changed
	    if (scrape.getanchorsFlag() != checkvalanchors.booleanValue()) {
 		    // reset anchors flag
		    if (anchors != null) {
			scrape.setanchorsFlag(anchors);
			// indicate change has been made to flags
			changeflag = true;
		    }
	    }
	    if (scrape.getstripFlag() != checkvalstrip.booleanValue()) {
 		    // reset strip flag
		    if (strip != null) {
			scrape.setstripFlag(anchors);
			// indicate change has been made to flags
			changeflag = true;
		    }
	    }
	}
    }


    /**
     * getter method for a result string from a scrapedata object
     *
     * @param id  unique key for requested scrape
     *
     * @return results from scrapeidentified by id
     *
     */
    public String getResults(String id) throws JspException {
	ScrapeData scrape = (ScrapeData)scrapes.get(id);

        // error will occur if page or scrapeid in result tag does not exist
	try {
	    return scrape.getResult();
	} catch (NullPointerException ne) {
	    throw new JspException
                            ("page or scrapeid in result tag do not exist");
	}
    }

    /**
     * set the name and value of any extra headers to be sent
     *
     * @param name   string that is the name of an extra header to be sent
     * @param value  string that is the value of an extra header to be sent
     */
    protected final void setHeader(String name, String value) {
        if (name == null) {
            this.name = new ArrayList(5);
            this.value = new ArrayList(5);
	}
	this.name.add(name);
        this.value.add(value);
    }

    /**
     * get the http headers
     *
     * @return name   ArrayList of the names of http headers to be sent
     * @return value  ArrayList or the values of http headers to be sent
     *
     */
    public ArrayList getHeaders() {
        if (name == null) {
            return null;
	} else {
            ArrayList list = new ArrayList(2);
            list.add(name);
            list.add(value);
            return list;
	}
    }

    /**
     * setter method for newflag only called to set newflag to false
     *
     */
    public void setNewflag() {
	newflag = false;
    }

    /**
     * getter method for newflag
     *
     * @return boolean value of newflag true if new scrape exists else false
     *
     */
    public boolean getNewFlag() {
	return newflag;
    }

    /**
     * set the value of proxy port
     *
     * @param value  the proxy port to use for the connection as a String
     *
     */
    public final void setProxyPort(int value) {
	pport = value;
    }

    /**
     * get the value of the proxy port
     *
     * @return - int the proxy port number
     *
     */
    public final int getProxyPort() {
        return pport;
    }

    /**
     * set the value of proxy server
     *
     * @param value  the proxy server to use for the connection
     *
     */
    public final void setProxyServer(String value) {
	pserver = value;
    }

    /**
     * get the value of the proxy port
     *
     * @return - String the name or the proxy server
     *
     */
    public final String getProxyServer() {
        return pserver;
    }
   /**
     * set the pass word to access the client keystore
     *
     * @param value  password to the client keystore
     *
     */
    public final void setClientPass(String value) {
	sslclientpass = value;
    }

    /**
     * set the username and password values for authentication to the proxy server
     *
     * @param name  username
     * @param pass  password
     * @param base64  base64 encoded username and password
     *
     */
    public final void setAuth(String name, String pass) {
	if (name != null && pass != null)
	    auth = "Basic " + 
		   new BASE64Encoder().encode((name + ":" + pass).getBytes());
    }

    /**
     * get the base64 encoded auth string for proxy authorization
     *
     * @return - String base64 encoded authorization for the proxy server
     *
     */
    public final String getAuth() {
        return auth;
    }

    /**
     * set the value of secure
     *
     * @param value  true if the connection is to be made via https the default 
     *               is false
     *
     */
    public final void setSSL(boolean value) {
	ssl = value;
    }

    /**
     * get secure
     *
     * @return - boolean value of secure flag
     */
    public final boolean getSSL() {
        return ssl;
    }

    /**
     * getter method for the key set of the HashMap scrapes
     *
     * @return the keys that the scrapes for this page are hashed to
     *
     */
    public final Set getKeySet() {
	return scrapes.keySet();
    }

    /**
     * setter method for lastscrape
     *
     * @param time  current time
     *
     */
    public void setLastScrape(long time) {
	lastscrape = time;
    }

    /**
     * getter method for lastscrape
     *
     * @param time  current time
     *
     */
    public long getLastScrape() {
	return lastscrape;
    }

    /**
     * sets the exception text to make the error in the jsp page easier for the
     * author to find
     *
     * @param begin  the beginning marker for scrape where error occured
     * @param end  the end marker for the scrape where error occured
     *
     */
    public void setExceptionText(String begin, String end) {
        exceptiontext = new String
                    ("there is a syntax error in " + begin + " or " + end + 
       " for the scrape. A character probably needs to be escaped for perl\n"
       + " See docs for help if you don't know perl");
    }

    /**
     * set exception to true, a malformedpatternexception has been thrown in
     * page
     *
     */
    public void setException() {
	exception = true;
    }

    /**
     * getter method for changeflag
     *
     * @return boolean  value of changeflag true if a scrape has been changed
     *                  else false
     *
     */
    public boolean getChangeFlag() {
	return changeflag;
    }

    /**
     * getter method for a single scrapedata object from HashMap scrapes
     *
     * @param key  the value the requested scrapedata object is keyed to
     *
     * @return the requested scrapedata boject
     *
     */
    public ScrapeData getScrape(String key) {
	return (ScrapeData)scrapes.get(key);
    }

    /**
     * setter method for pagecontext
     *
     * @param page  the page context object for this page
     *
     */
    public void setPageContext(PageContext page) {
	pagecontext = page;
    }

    /**
     * getter method for pagecontext
     *
     * returns the PageContext object for this page
     *
     */
    public PageContext getPageContext() {
	return pagecontext;
    }

    /**
     * checks the scrapeint, if enough time has passed it starts the getPage
     * thread to go out and get the page, and sets scrapeing to true, then if
     * newflag it will wait for the thread to finish running, otherwise it will
     * just fall through and return the already stored results
     *
     * @param url  url of the page to be scraped
     * @param time  length of time to wait before rescrape
     * @param proxy  boolean value that says whether or not to use a proxy server
     * @param pc  PageContext for this JSP page
     * @param cs charset to be used to scrape the page
     *
     */
   public void scrapePage(String url, long time, PageContext pc, String cs)
     throws JspException {
	long currenttime = new Date().getTime();  // get the current time

	// check to see if a scrape is needed
	if (((currenttime - lastscrape) > time) || newflag || changeflag) { 
	    // if it is time to rescrape but scraping did not get reset, reset it
	    if (scraping.booleanValue() && !page.isAlive()) {
		scraping = new Boolean(false);
	    }
	    if (!scraping.booleanValue()) {
                // if a scrape is in progress wait until scrape is finished
	        synchronized (scraping) {
	            if ((page == null) || !page.isAlive()) {
                        // create thread page if it doesn't exist check for a
			// proxy connection
			try {
                            page = new Page(url, this, pc, cs);
			    /*if (pport != -1 && pserver != null)
				page = new Page(url, this, pc, pport, pserver, auth);
			 //page = new Page(url, this, pc, pport, pserver, ssl, auth);
                           else
				page = new Page(url, this, pc);
			    //page = new Page(url, this, pc, ssl);
                            */
			} catch (MalformedURLException mue) {
			    pc.getServletContext().log("PageData.scrapePage(): " 
						       + mue.getMessage());
			}
		    }
	            if ((((currenttime - lastscrape) > time) || newflag ||
			changeflag) && page != null) {
			// set scraping flag 
		        scraping = new Boolean(true);
                        page.start();
	            }
                }
	    }
	}

	// reset the scraping flag to false if the page thread is not running but
	// the scraping flag is true
	if (scraping.booleanValue() && !page.isAlive()) {
	    scraping = new Boolean(false);
	}

        if (scraping.booleanValue() && (newflag || changeflag) && (page != null)) {
	    try {
	        page.join();    // wait for scrape to finish
		changeflag = false; // reset changeflag
		scraping = new Boolean(false); // done scraping reset flag
	    } catch (InterruptedException ie) {
		// exception shouldn't happen if it does log it to the server
	        pc.getServletContext().
                               log("PageData.scrapePage(): Page thread interrupted " 
				   + ie.toString());
	    }
	}
	// check to see if a MalformedPatternException was thrown if so throw
	// JspException for JSP page builder
	if (exception) {
	    exception = false; // reset exception flag
	    throw new JspException(exceptiontext);
	}
    }
}

 /**
  * Create an http request for the specified URL, check to see if time has
  * elapsed, if so get page, check last modified header of page, and if
  * necessary make the request
  *
  */
class Page extends Thread {

    private HttpConnection connection; // object to create an http request
    private long lastmodified;          // time the page was last modified
    private long expires;             // http header = time the page expires
    private URL url;                // url from the page to be scraped
    private PageData pagedata;    // pagedata object that holds data on this url
    // char array to hold the source page from the http request
    private char source[];
    // max size of the buffer that the http request is read into
    private final long MAX_BUFFER_SIZE = 50000;
    // pagecontext that the servlet resides in, used for logging to the server
    private PageContext pageContext;
    // value determines if a proxy server is to be used for the http connection
    private boolean proxy = false;
    // the port to use for the proxy connection
    private int pport = -1;
    // the proxy server to use for the connection
    private String pserver = null;
    // authentication string for authentication to the proxy server name:password
    private String authstring = null;
    // boolean value determines if the connection to to travel via a secure
    // connection
    private boolean ssl = false;
    // charset to be used to scrape the page
    private String charset = null;

    /**
     * Constructor for Page
     *
     * @param url  the URL of the page to get scraped
     * @param page  PageData object for the page to get scraped
     * @param pc  PageContext the taglibrary is running in used for logging
     * @param secure boolean flag to determine if the connection is via http of https
     * @param cs charset to be used to scrape the page
     *
     * @throws MalformedURLException - 
     *
     */
    Page(String url, PageData page, PageContext pc, String cs) 
	//Page(String url, PageData page, PageContext pc, boolean secure) 
	throws MalformedURLException {
	this.url = new URL(url);
	// get the file part of the url make it "/" if it doesn't exist so that the
	// front page can be accessed
        if(this.url.getFile().length() == 0)
            this.url = new URL(url + "/");
	pagedata = page;
	pageContext = pc;
    charset = cs;
	//ssl = secure;
    }

    /**
     * Constructor for Page
     *
     * @param url  the URL of the page to get scraped
     * @param page  PageData object for the page to get scraped
     * @param pc  PageContext the taglibrary is running in used for logging
     * @param port  the port to connect to on the proxy server
     * @param server  the proxy server to connect to
     * @param secure boolean flag to determine if the connection is via http of https
     * @param name  username used for authentication to the proxy server
     * @param pass  password used for authentication to the proxy server
     *
     * @throws MalformedURLException - 
     *
     */
    Page(String url, PageData page, PageContext pc, int port, String server, 
         String proxyauth) throws MalformedURLException {
        //boolean secure, String proxyauth) throws MalformedURLException {
	this.url = new URL(url);
	// get the file part of the url make it "/" if it doesn't exist so that the
	// front page can be accessed
        if(this.url.getFile().length() == 0)
            this.url = new URL(url + "/");
	pagedata = page;
	pageContext = pc;
	pport = port;
	pserver = server;
	authstring = proxyauth;
	proxy = true;
	//ssl = secure;
    }

    public void run() {
        long current = new Date().getTime();  // get current time

        // make http connection to url
         try {
	     // create new HttpUrlConnection
             connection = new HttpConnection(url, pagedata, pageContext);
	     /*if (!proxy)
		 //connection = new HttpConnection(url, ssl, pageContext);
		 connection = new HttpConnection(url, pageContext);
             else
		 //new HttpConnection(url, pport, pserver, ssl, authstring);
		 connection = new HttpConnection(url, pport, pserver, 
		 authstring, pageContext);*/
	     connection.setRequestMethod("HEAD");
	     connection.connect();
	     connection.sendRequest();

	     // check response status code a code of 200 is a successful
      	     // connection
	     if (connection.getResponseCode() >= 300) {
		 pageContext.getServletContext().
                   log("Page.run(): Error Occured: " 
		       + connection.getResponseMessage());
   	     } else {
		 // get expires header
		 if ((expires =(long)connection.getExpiration()) == 0)
		     // do this if header does not exist
		     expires = current - 1;

	     	 // check for a new scrape for this page or that the Expires
		 // time for the page has passed
                 if((expires < current) || pagedata.getNewFlag() || 
		    pagedata.getChangeFlag()) {

		     // get lastmodified header
		     // getLastModified returns 0 if header does not exist
		     if ((lastmodified = (long)connection.getLastModified()) == 0)
			 // do this if header does not exist
			 lastmodified = pagedata.getLastScrape() + 1;

		     // check for a new scrape for this page or that Last-
		     // Modified time for the page has passed
	       	     if ((pagedata.getLastScrape() < lastmodified) || 
                            pagedata.getNewFlag() || pagedata.getChangeFlag()) {

			 // dissconnect so a new connection for a GET can be made
			 connection.disconnect();

			 // set lastscrape
			 pagedata.setLastScrape(current);

			 // set the request method to get
			 connection.setRequestMethod("GET");
			 // make the connection
			 connection.connect();
			 connection.sendRequest();

			 // check responce code from connection
			 if (connection.getResponseCode() >= 300) {
		             pageContext.getServletContext().
                                log("Page.run(): Error Occured: " +
			            connection.getResponseMessage());
			     // the connection did not occur return cached data
			     return;
			 }

			 // read http request into buffer return value is false
			 // if an error occured
			 if (streamtochararray(connection.getInputStream(),charset)) {
			     // perform the scrapes on this page
		       	     scrape();
			 }
			 // close the connection
			 connection.disconnect();
		     }
	         }
	     }
	 } catch (IOException ee) {
	     pageContext.getServletContext().
             log("Page.run(): " + ee.toString());
         }
     }

    /**
     * Helper routine to read the input stream into a char array
     *
     * @param in  The inputstream from the Http request
     *
     * @return a value of true if no error occured in reading the input stream
     *         otherwise false
     *
     */
    private boolean streamtochararray(InputStream in, String charset) {
        long sourcelength = 50000; // length of buffer inputstream is read into
	StringBuffer temp; // buffer used to chop unused portion of source
	boolean returnvalue = true;  // no error in reading from input stream
	// create a char stream from a byte stream
	InputStreamReader input = null;
    if ( charset == null ) {
      input = new InputStreamReader(in);
    } else {
      try {
        input = new InputStreamReader(in, charset);
      } catch( UnsupportedEncodingException exc ) {
        System.err.println( "WARNING: unsupported charset " + charset + ". Using default." );
        input = new InputStreamReader(in);
      }
    }
	boolean chop = false; // flag tells whether or not to truncate buffer
	int offset = 0; // offset in the input stream to start reading from
	int num; // number of chars read from the input stream


        sourcelength = (long)connection.getHeaderFieldInt("Content-Length",
			       (int)MAX_BUFFER_SIZE);

        // check that sourcelength is not greater than max allowed or 0
        if ((sourcelength > MAX_BUFFER_SIZE)) {
	    sourcelength = MAX_BUFFER_SIZE;
	}
	source = new char[(int)sourcelength];

	// flag marks if the inputstream was read at least once. it may contain
	// enough to scrape
	boolean check = false;
        try {  	// read the input stream into the buffer
            while((num = input.read(source, offset,
                          (int)(sourcelength - offset))) > 0) {
		offset += num;
		check = true;
            }
	// error occured in reading input stream set return value to false
	} catch (IOException e) {
	    if (!check)
		returnvalue = false;
	    pageContext.getServletContext().log("Page.streamtochararray(): Error " +
                                                "ocured while reading the " + 
						"inputstream " + e.toString());
	}

	if (chop) {
	    // truncate any extra buffer space if it wasn't needed
            temp = new StringBuffer().append(source);
            source = new char[temp.length() + 1]; // create new buffer
            temp.getChars(0, temp.length(), source,0); // fill new buffer
	}
        return returnvalue;
    }

    /**
     * Using regular expressions, parse the source from the http request for a
     * string specified by the delimiter strings obtained from the Scrape tag
     * then check flags and store the results
     *
     */
  public void scrape() {

    // object to compile regular expressions
    Perl5Compiler compiler = new Perl5Compiler(); 
    // object to match compiled regular expressions
    Perl5Matcher matcher = new Perl5Matcher();  
    Perl5Pattern pattern = null;  // pattern to be compiled into regex
    // used to perserve state across calls to contains() method
    MatchResult result;  // class for accessing results of pattern match
    // matcher class used to preserve position across calls to contains
    PatternMatcherInput input;
    String match;  // string value of result for dropping of end markers
    ScrapeData sd;  // data object that holds data on current scrape
    // set of keys for the hashmap scrapes
    Set scrapedatakeys = pagedata.getKeySet();
    // iterator for scrapedatakeys
    Iterator scrapesit = scrapedatakeys.iterator();
    Iterator scrapesit1 = scrapedatakeys.iterator();
    // String variable that will become the regular expression
    String regex = new String();

    // iterate through the scrapedata objects and perform a scrape for each one
    while(scrapesit.hasNext()) {

        // get next item from HashMap scrapedata
        sd = pagedata.getScrape((String)scrapesit.next());

        // build the regular expression
        regex = regex.concat(sd.getBegin().concat(".*?").concat(sd.getEnd()));

        //attempt to compile the pattern try to catch MalformedPatternException
        try {
           // compile pattern with singleline_mask
            pattern = (Perl5Pattern)compiler.compile(regex,
                               Perl5Compiler.SINGLELINE_MASK);
        } catch (MalformedPatternException e) {
	    // if exception occurs store it to be kicked out later otherwise
	    // could not get out of run()
	    pagedata.setException();
	    pagedata.setExceptionText(sd.getBegin(), sd.getEnd());
        }

        matcher.contains(source, pattern); // attempt to match the regex

        result = matcher.getMatch(); // get returned match

        if(result != null) {
            // get the result to a String value from a string
            StringBuffer matchbuffer = new StringBuffer();
            matchbuffer.append(result.toString());
            match = new String(matchbuffer);

	    // default value is false and begin and end anchors are not part of
	    // the scrape
            if(!sd.getanchorsFlag()) {
		// chop begin and end marker from final result
                match = match.substring(sd.getBegin().length(), 
                                         match.lastIndexOf(sd.getEnd()));
            }

	    // if stripflag remove tags from result string
            if(sd.getstripFlag()) {
                regex = ">.*?<";
                // string that is built as tags are removed from result
                String finalresult = new String();
                // attempt to compile the pattern try to catch 
                //MalformedPatternException
                try {
                    // compile pattern with singleline_mask
                    pattern = (Perl5Pattern)compiler.compile(regex,
                               Perl5Compiler.SINGLELINE_MASK);
                } catch (MalformedPatternException e) {
		    // an error will never occur here since the regex is
		    // predefined
                }

		// if there is text before the first tag add it to the
		// final result
		if ((match.indexOf('<') < match.indexOf('>')) && 
		                                    (match.indexOf('<') != 0))
		    finalresult = match.substring(0, match.indexOf('<')).
                                                           concat(" ");

		// set patternmatcherinput so multiple matches can be made
		input = new PatternMatcherInput(match);

                // loop until no tags are left in result string
                while(matcher.contains(input, pattern)) {

		    matchbuffer.setLength(0); // reset matchbuffer for reuse

                    result = matcher.getMatch(); // get the result
		    // add current result to to final result string
                    matchbuffer.append(result.toString());
                    match = new String(matchbuffer);

		    // check to see that match is not a match on ><
		    if (match.length() > 2) {
     	                finalresult = finalresult.concat(match.substring(1,
                                           match.indexOf('<'))).concat(" ");
		    }
	        }

		// reset match to original string so that any trailing text can
		// be added to final result
		match = input.toString();

		// if there is trailing text outside of tags add to the result
		if (match.lastIndexOf('>') > match.lastIndexOf('<'))
		    finalresult = finalresult.concat(match.substring(
                                  match.lastIndexOf('>') + 1, match.length()));

	        match = finalresult; // set final result of scrape to match

	    }
            sd.setResult(match); // set scrape results in scrapedata object
	    pagedata.setNewflag(); // successful scrape set newflag to false
        } else {
            sd.setResult("");
        }
	regex = ""; // clear regex for use again
	match = null;  // clear match for reuse
    }
  }
}
