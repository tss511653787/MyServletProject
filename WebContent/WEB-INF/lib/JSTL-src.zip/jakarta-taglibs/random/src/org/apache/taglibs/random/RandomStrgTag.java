/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.random;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

/**
 * RandomStrg tag will create a random string generator accessiable by the 
 * <b>jsp:getProperty</b> tag..
 *
 * &lt;tag&gt;
 *	&lt;name&gt;random&lt;/name&gt;
 *	&lt;tagclass&gt;org.apache.taglibs.random.RandomTag&lt;/tagclass&gt;
 *	&lt;bodycontent&gt;empty&lt;/bodycontent&gt;
 *	&lt;info&gt;Creates an variable length random string generator&lt;/info&gt;
 *
 *	&lt;attribute&gt;
 *		&lt;name&gt;id&lt;/name&gt;
 *		&lt;required&gt;true&lt;/required&gt;
 *		&lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *	&lt;/attribute&gt;
 *	&lt;attribute&gt;
 *		&lt;name&gt;length&lt;/name&gt;
 *		&lt;required&gt;false&lt;/required&gt;
 *		&lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *	&lt;/attribute&gt;
 *	&lt;attribute&gt;
 *		&lt;name&gt;map&lt;/name&gt;
 *		&lt;required&gt;false&lt;/required&gt;
 *		&lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *	&lt;/attribute&gt;
 *	&lt;attribute&gt;
 *		&lt;name&gt;charset&lt;/name&gt;
 *		&lt;required&gt;false&lt;/required&gt;
 *		&lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *	&lt;/attribute&gt;
 *	&lt;attribute&gt;
 *		&lt;name&gt;algorithm&lt;/name&gt;
 *		&lt;required&gt;false&lt;/required&gt;
 *		&lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *	&lt;/attribute&gt;
 *	&lt;attribute&gt;
 *		&lt;name&gt;provider&lt;/name&gt;
 *		&lt;required&gt;false&lt;/required&gt;
 *		&lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *	&lt;/attribute&gt;
 * &lt;/tag&gt;
 *
 * @author Rich Catlett
 *
 * @version 1.0
 *
 */

public class RandomStrgTag extends TagSupport {

    /**
     * flag determines if all chars ar to be used
     */
    private boolean allchars = false;
    /**
     * length of random string defaults to 8
     */
    private Integer length = new Integer(8);
    /**
     * list of all generated strings, list is stored at the application level
     */
    private HashMap hmap;
    /**
     * Hashmap to check keys against to see if they have already been used
     */
    private String map = null;
    /**
     * ArrayList for the lowerbound of the char sets
     */
    private ArrayList lower = null;
    /**
     * ArrayList for the upperbound of the char sets
     */
    private ArrayList upper = null;
    /**
     * ArrayL for the set of chars that aren't part of a range
     */
    private char[] single = null;
    /**
     * counter for position in the array single
     */
    private int singlecount = 0;
    /**
     * the algorithm to use for a SecureRandom object
     */
    private String algorithm = null;
    /**
     * the provider package to check for the algorithm
     */
    private String provider = null;
    /**
     * the charset to use for generating the random string
     */
    private String charset = null;

    /**
     * implementation of method from the Tag interface that tells the JSP what
     * to do upon encountering the start tag for this tag set
     *
     * @return SKIP_BODY - integer value telling the JSP engine to not evaluate
     *                      the body of this tag
     *
     * @throws JspException  thrown when error occurs in processing the body of
     *                       this method
     *
     */
    public final int doStartTag() throws JspException {

	// create the class that will become the script variable available through
	// the jsp:getProperty tag
	RandomStrg random = new RandomStrg();

	// set the default for the charset to a-ZA-Z0-9
	if (charset != null) {
            generateCharset(charset);
        } else {
	    generateCharset("a-zA-Z0-9");
        }

	if (map != null) {
	    try {

		// check if the list is to be used if so get list
		if ((hmap = (HashMap) pageContext.findAttribute(map)) == null)
		    // named hashmap does not exist throw error out to the author
		    throw new JspException("A hashmap does not exist in any " +
					   "scope under the name " + map);
	    } catch (ClassCastException cce) {
		throw new JspException("The named attribute exists but it is not" +
				       " a hashmap.");
	    }

	    random.setHmap(hmap);  // set the Hashmap in the script variable
	}

	// if ranges exist set them in the script variable
	if (lower != null)
	    random.setRanges(lower, upper);

	// if a set of single chars exists set that in the script variable
	if (single != null)
	    random.setSingle(single, singlecount);

	random.setLength(length);  // set the length of the random string

	random.setAllchars(allchars); // set the allchars flag

	// check to see if algorithm and provider have been set and set them in the
	// randomnum 
	if (algorithm != null)
	    random.setAlgorithm(algorithm);
	if (provider != null)
	    random.setProvider(provider);

	// generate the random object to be used either a Random or SecureRandom
	random.generateRandomObject();

	// place the script variable in the page scope
	pageContext.setAttribute(id, random, PageContext.PAGE_SCOPE);

	return SKIP_BODY;
    }

    /**
     * set the name of the map
     *
     * @param value  name of the hashmap to search for on the server that contains
     *               the keys to compare the random strings to
     */
    public final void setMap(String value) {
	map = value;
    }

    /**
     * set the length of the password
     *
     * @param value  length of the random string to be generated
     */
    public final void setLength(String value) {
	try {
	    length = new Integer(value);
	} catch (NumberFormatException ne) {
	    pageContext.getServletContext().log("length attribute could not be" +
			       " turned into an Integer default value was used");
	}
    }

    /**
     * set the algorithm name
     *
     * @param value  name of the algorithm to use for a SecureRandom object
     *
     */
    public final void setAlgorithm(String value) {
	algorithm = value;
    }

    /**
     * set the provider name
     *
     * @param value  name of the package to check for the algorithm
     *
     */
    public final void setProvider(String value) {
	provider = value;
    }

    /**
     * set the range of characters to use
     *
     * @param value  the range of characters to use could be any char from a-z, A-Z
     *               0-9 or ! @ # $ % ^ & * ( ) _ \- + = [ ] { } \ | ; : ' " , . / 
     *               < > ?
     *
     */
    public final void setCharset(String value) {
        charset = value;
    }

    private void generateCharset(String value) {
	// values tells the method whether or not to check for single chars
	boolean more = true;

        // Reset private variables
        allchars = false;
        single = null;
        singlecount = 0;

	// create the arraylists to hold the upper and lower bounds for the char
	// ranges
	lower = new ArrayList(3);
	upper = new ArrayList(3);

	// user has chosen to use all possible characters in the random string
	if (value.compareTo("all") == 0) {
	    allchars = true;  // set allchars flag
	    // all chars are to be used so there are no single chars to sort 
	    // through
	    more = false;
	} else if ((value.charAt(1) == '-') && (value.charAt(0) != '\\')) {
	    // run through the ranges at most 3 
	    while (more && (value.charAt(1) == '-')){

		// check to make sure that the dash is not the single char
		if (value.charAt(0) == '\\')
		    break;
		else {
		    // add upper and lower ranges to there list
		    lower.add(new Character(value.charAt(0)));
		    upper.add(new Character(value.charAt(2)));
		}

		// check to see if there is more to the charset
		if (value.length() <= 3)
		    more = false;
		else
		    // create a new string so that the next range if there is one
		    // starts it
		    value = value.substring(3);
	    }
	}

	// if more = false there are no single chars in the charset
	if (more) {

	    single = new char[30];  // create single

	    // create a set of tokens from the string of single chars
	    StringTokenizer tokens = new StringTokenizer(value);

	    while (tokens.hasMoreTokens()) {
		// get the next token from the string
		String token = tokens.nextToken();

		if (token.length() > 1)
		    // char is a - add it to the list
		    single[singlecount++] = '-';

		// add the current char to the list
		single[singlecount++] = token.charAt(0);
	    }
	}
    }
}
