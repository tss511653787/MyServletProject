/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.regexp;

import java.util.*;
import org.apache.oro.text.*;
import org.apache.oro.text.perl.*;
import org.apache.oro.text.regex.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * JSP Tag <b>existsmatch</b>, used to determine if a regular
 * expression match can be found in the text.
 * <p>
 * Includes the body of the tag if the a match was found.
 * <p>
 * The attribute <b>regexp</b> must be set to the id of a <b>regexp</b>
 * tag and the <b>text</b> attribute must be set to the id of a
 * <b>text</b> tag.
 * <p>
 * You can set the optional tag attribute <b>value</b> to <i>true</i> or
 * <i>false</i>.  The body of the tag is included if existsmatch matches
 * the value.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;existsmatch&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.regexp.ExistsMatchTag&lt;/tagclass&gt;
 * &lt;bodycontent&gt;JSP&lt;/bodycontent&gt;
 * &lt;info&gt;Includes the body of the tag if the regexp attribute exists.&lt;/info&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;regexp&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;text&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;value&lt;/name&gt;
 *     &lt;required&gt;false&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 * </pre>
 *
 * @see RegexpTag
 * @see TextTag
 * @see RegexpData
 * @see TextData
 *
 * @author Glenn Nielsen
 */

public class ExistsMatchTag extends TagSupport
{
    private String regexpid = null;
    private String textid = null;
    private boolean value = true;

    /**
     * Includes the body of the tag if the regexp finds a match in text.
     *
     * @return SKIP_BODY if existsmatch doesn't match value, EVAL_BODY_include if existsmatch matches value
     */
    public final int doStartTag() throws JspException
    {
	boolean result = false;

	TextData td = (TextData)pageContext.getAttribute(textid,PageContext.PAGE_SCOPE);
	if( td == null )
	    throw new JspException(
		"regexp tag existsmatch could not find text tag with id: " +
		textid);
        RegexpData rd = (RegexpData)pageContext.getAttribute(regexpid,PageContext.PAGE_SCOPE);
        if( rd == null )
            throw new JspException(
                "regexp tag existsmatch could not find regexp tag with id: " +
                regexpid);

	Perl5Util perl = new Perl5Util(rd.getPatternCache());
	if( perl.match(rd.getRegexp(),td.getText()) )
	    result = true;

	if( value == result )
	    return EVAL_BODY_INCLUDE;

	return SKIP_BODY;
    }

    /*
     * Set the required attribute <b>regexp</b>
     *
     * @param String name of regexp script variable
     */
    public final void setRegexp(String str)
    {   
	regexpid = str;
    }

    /*
     * Set the required attribute <b>text</b>
     *
     * @param String name of text script variable
     */
    public final void setText(String str)
    {               
        textid = str;
    }

    /**
     * Set the optional tag attribute <b>value</b> to true or false.
     *
     * @param boolean <b>true</b> or <b>false</b>
     */
    public final void setValue(boolean value)
    {
	this.value = value;
    }

}
